'use client'

import Link from 'next/link'
import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'
import { cn } from '@/lib/utils'

const guides = [
  {
    category: 'Getting Started',
    items: [
      {
        title: 'Your First Reasoning Session',
        description: 'Learn how to create a session, log beliefs, and track inferences step by step.',
        duration: '10 min',
        difficulty: 'Beginner',
        href: '/guides/first-session',
      },
      {
        title: 'Setting Up Constraints',
        description: 'Define rules that your AI agents must follow to ensure compliant behavior.',
        duration: '15 min',
        difficulty: 'Beginner',
        href: '/guides/constraints',
      },
      {
        title: 'Understanding the Neural Graph',
        description: 'Visualize and navigate the causal relationships between beliefs and decisions.',
        duration: '20 min',
        difficulty: 'Intermediate',
        href: '/guides/neural-graph',
      },
    ],
  },
  {
    category: 'Industry Guides',
    items: [
      {
        title: 'Healthcare AI Compliance',
        description: 'Implement HIPAA-compliant reasoning for medical diagnosis agents.',
        duration: '30 min',
        difficulty: 'Advanced',
        href: '/guides/healthcare',
      },
      {
        title: 'Legal Document Review',
        description: 'Build auditable legal review agents with full reasoning transparency.',
        duration: '25 min',
        difficulty: 'Advanced',
        href: '/guides/legal',
      },
      {
        title: 'Financial Risk Assessment',
        description: 'Create explainable credit scoring and risk evaluation agents.',
        duration: '25 min',
        difficulty: 'Advanced',
        href: '/guides/finance',
      },
    ],
  },
  {
    category: 'Integration',
    items: [
      {
        title: 'Integrating with LangChain',
        description: 'Add Velarix reasoning tracking to your LangChain agents.',
        duration: '15 min',
        difficulty: 'Intermediate',
        href: '/guides/langchain',
      },
      {
        title: 'Real-time Monitoring with Webhooks',
        description: 'Set up webhooks to receive instant notifications on reasoning events.',
        duration: '20 min',
        difficulty: 'Intermediate',
        href: '/guides/webhooks',
      },
      {
        title: 'Building Custom Dashboards',
        description: 'Use the API to create custom visualization dashboards.',
        duration: '30 min',
        difficulty: 'Advanced',
        href: '/guides/custom-dashboards',
      },
    ],
  },
]

const difficultyColors: Record<string, string> = {
  Beginner: 'bg-green-500/20 text-green-400',
  Intermediate: 'bg-amber-500/20 text-amber-400',
  Advanced: 'bg-red-500/20 text-red-400',
}

export default function GuidesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">Guides</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Step-by-step tutorials to help you get the most out of Velarix.
            </p>
          </div>

          {/* Guides */}
          <div className="space-y-16">
            {guides.map((category) => (
              <div key={category.category}>
                <h2 className="text-2xl font-semibold mb-6">{category.category}</h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {category.items.map((guide) => (
                    <Link
                      key={guide.href}
                      href={guide.href}
                      className="group flex flex-col p-6 rounded-xl border border-border/50 bg-card/50 hover:border-primary/30 hover:bg-card transition-all"
                    >
                      <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                        {guide.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4 flex-1">
                        {guide.description}
                      </p>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          {guide.duration}
                        </span>
                        <span className={cn('text-xs px-2 py-0.5 rounded-full', difficultyColors[guide.difficulty])}>
                          {guide.difficulty}
                        </span>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="mt-16 p-8 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-card/50 to-accent/10 text-center">
            <h3 className="text-xl font-semibold mb-2">Have a guide request?</h3>
            <p className="text-muted-foreground mb-4">
              We're always adding new content. Let us know what you'd like to learn.
            </p>
            <Link href="/contact" className="text-primary hover:underline">
              Submit a request
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
