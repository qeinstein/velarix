'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'

const plans = [
  {
    name: 'Starter',
    description: 'For small teams getting started with AI reasoning.',
    price: { monthly: 99, annual: 79 },
    features: [
      '10,000 reasoning events/month',
      '3 AI agents',
      '7-day log retention',
      'Basic neural graph',
      'Email support',
      'API access',
    ],
    cta: 'Start Free Trial',
    popular: false,
  },
  {
    name: 'Pro',
    description: 'For growing teams with compliance requirements.',
    price: { monthly: 499, annual: 399 },
    features: [
      '100,000 reasoning events/month',
      'Unlimited AI agents',
      '90-day log retention',
      'Advanced neural graph',
      'Priority support',
      'Webhook integrations',
      'Custom constraints',
      'Team collaboration',
    ],
    cta: 'Start Free Trial',
    popular: true,
  },
  {
    name: 'Enterprise',
    description: 'For organizations with strict regulatory needs.',
    price: { monthly: null, annual: null },
    features: [
      'Unlimited reasoning events',
      'Unlimited AI agents',
      'Unlimited log retention',
      'Full neural graph with playback',
      'Dedicated support',
      'Custom integrations',
      'On-premise deployment',
      'SOC2 & HIPAA compliance',
      'SLA guarantees',
      'Custom contracts',
    ],
    cta: 'Contact Sales',
    popular: false,
  },
]

export default function PricingPage() {
  const [billing, setBilling] = useState<'monthly' | 'annual'>('annual')

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">
              <span className="text-balance">
                Simple,{' '}
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  transparent
                </span>{' '}
                pricing
              </span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
              Start with a 14-day free trial. No credit card required. Scale as your AI systems grow.
            </p>

            {/* Billing toggle */}
            <div className="flex items-center justify-center gap-3 mt-8">
              <span className={cn('text-sm', billing === 'monthly' ? 'text-foreground' : 'text-muted-foreground')}>
                Monthly
              </span>
              <button
                onClick={() => setBilling(billing === 'monthly' ? 'annual' : 'monthly')}
                className={cn(
                  'relative w-12 h-6 rounded-full transition-colors',
                  billing === 'annual' ? 'bg-primary' : 'bg-secondary'
                )}
              >
                <span
                  className={cn(
                    'absolute top-1 w-4 h-4 rounded-full bg-background transition-transform',
                    billing === 'annual' ? 'translate-x-7' : 'translate-x-1'
                  )}
                />
              </button>
              <span className={cn('text-sm', billing === 'annual' ? 'text-foreground' : 'text-muted-foreground')}>
                Annual
              </span>
              <span className="ml-2 text-xs px-2 py-1 rounded-full bg-accent/20 text-accent">
                Save 20%
              </span>
            </div>
          </div>

          {/* Plans */}
          <div className="grid md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={cn(
                  'relative rounded-2xl border p-8 transition-all duration-300 hover:border-primary/50',
                  plan.popular
                    ? 'border-primary/50 bg-card/80 scale-105 shadow-lg shadow-primary/10'
                    : 'border-border/50 bg-card/50'
                )}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="px-3 py-1 text-xs font-medium rounded-full bg-primary text-primary-foreground">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="mb-6">
                  <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                  <p className="text-sm text-muted-foreground">{plan.description}</p>
                </div>

                <div className="mb-6">
                  {plan.price.monthly !== null ? (
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl font-bold">
                        ${billing === 'monthly' ? plan.price.monthly : plan.price.annual}
                      </span>
                      <span className="text-muted-foreground">/month</span>
                    </div>
                  ) : (
                    <div className="text-4xl font-bold">Custom</div>
                  )}
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3 text-sm">
                      <svg className="w-5 h-5 text-accent shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>

                <Link href={plan.name === 'Enterprise' ? '/contact' : '/signup'}>
                  <Button
                    className={cn(
                      'w-full',
                      plan.popular
                        ? 'bg-primary hover:bg-primary/90 text-primary-foreground'
                        : 'bg-secondary hover:bg-secondary/80'
                    )}
                  >
                    {plan.cta}
                  </Button>
                </Link>
              </div>
            ))}
          </div>

          {/* FAQ Teaser */}
          <div className="mt-20 text-center">
            <p className="text-muted-foreground">
              Have questions?{' '}
              <Link href="/contact" className="text-primary hover:underline">
                Contact our sales team
              </Link>{' '}
              or check our{' '}
              <Link href="/docs" className="text-primary hover:underline">
                documentation
              </Link>
              .
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
