'use client'

import Link from 'next/link'
import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'

const team = [
  {
    name: 'Sarah Chen',
    role: 'Co-founder & CEO',
    bio: 'Former ML lead at DeepMind. PhD in Explainable AI from Stanford.',
    initials: 'SC',
  },
  {
    name: 'Marcus Rodriguez',
    role: 'Co-founder & CTO',
    bio: 'Ex-Google Brain engineer. Built production ML systems serving billions.',
    initials: 'MR',
  },
  {
    name: 'Dr. Michael Torres',
    role: 'Head of Research',
    bio: 'Published researcher in causal inference and interpretable ML. Previously at MIT CSAIL.',
    initials: 'MT',
  },
  {
    name: 'Alex Kim',
    role: 'Engineering Lead',
    bio: 'Former tech lead at Stripe. Expert in high-performance distributed systems.',
    initials: 'AK',
  },
  {
    name: 'Dr. Priya Patel',
    role: 'Head of Compliance',
    bio: 'Former healthcare compliance officer. Expert in HIPAA, SOC2, and regulatory frameworks.',
    initials: 'PP',
  },
  {
    name: 'James Wilson',
    role: 'Head of Design',
    bio: 'Previously led design at Linear and Figma. Passionate about developer experience.',
    initials: 'JW',
  },
]

const values = [
  {
    title: 'Transparency First',
    description: 'We believe AI should be explainable by default, not as an afterthought.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
      </svg>
    ),
  },
  {
    title: 'Trust Through Rigor',
    description: 'Regulated industries demand precision. We meet that standard in everything we build.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
  },
  {
    title: 'Developer Obsession',
    description: 'APIs should be elegant. Documentation should be complete. Integration should be painless.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
      </svg>
    ),
  },
]

const investors = [
  'Sequoia Capital',
  'Andreessen Horowitz',
  'Greylock Partners',
  'First Round Capital',
]

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-5xl mx-auto">
          {/* Hero */}
          <div className="text-center mb-20">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-6">
              <span className="text-balance">
                Making AI{' '}
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  trustworthy
                </span>{' '}
                by default
              </span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
              We're building the infrastructure layer that lets AI agents explain their reasoning. 
              Because trust isn't optional in healthcare, legal, and finance.
            </p>
          </div>

          {/* Mission */}
          <div className="mb-20 p-8 rounded-2xl border border-border/50 bg-card/50">
            <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
            <p className="text-muted-foreground leading-relaxed">
              AI agents are becoming the backbone of critical decisions in regulated industries. 
              But without transparency, they remain black boxes that auditors can't trust and regulators can't approve. 
              We're building the reasoning layer that changes this—giving every AI agent the ability to explain 
              its beliefs, track its inferences, and justify its decisions in real-time.
            </p>
          </div>

          {/* Values */}
          <div className="mb-20">
            <h2 className="text-2xl font-semibold mb-8 text-center">Our Values</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {values.map((value) => (
                <div key={value.title} className="p-6 rounded-xl border border-border/50 bg-card/50 text-center">
                  <div className="inline-flex p-3 rounded-xl bg-primary/10 text-primary mb-4">
                    {value.icon}
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{value.title}</h3>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Team */}
          <div className="mb-20">
            <h2 className="text-2xl font-semibold mb-8 text-center">Leadership Team</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {team.map((member) => (
                <div key={member.name} className="p-6 rounded-xl border border-border/50 bg-card/50">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-4">
                    <span className="text-sm font-semibold text-background">{member.initials}</span>
                  </div>
                  <h3 className="font-semibold">{member.name}</h3>
                  <p className="text-sm text-primary mb-2">{member.role}</p>
                  <p className="text-sm text-muted-foreground">{member.bio}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Investors */}
          <div className="mb-20">
            <h2 className="text-2xl font-semibold mb-8 text-center">Backed By</h2>
            <div className="flex flex-wrap justify-center gap-8">
              {investors.map((investor) => (
                <div key={investor} className="px-6 py-3 rounded-xl border border-border/50 bg-card/50">
                  <span className="text-sm font-medium text-muted-foreground">{investor}</span>
                </div>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div className="p-8 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-card/50 to-accent/10 text-center">
            <h3 className="text-2xl font-semibold mb-4">Join Our Mission</h3>
            <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
              We're hiring across engineering, research, and go-to-market. Help us make AI explainable.
            </p>
            <Link
              href="/careers"
              className="inline-flex h-10 px-6 items-center justify-center rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
            >
              View Open Positions
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
