'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'
import { cn } from '@/lib/utils'

const endpoints = [
  {
    category: 'Sessions',
    items: [
      { method: 'POST', path: '/v1/sessions', description: 'Create a new reasoning session' },
      { method: 'GET', path: '/v1/sessions', description: 'List all sessions' },
      { method: 'GET', path: '/v1/sessions/:id', description: 'Get session details' },
      { method: 'DELETE', path: '/v1/sessions/:id', description: 'End a session' },
    ],
  },
  {
    category: 'Beliefs',
    items: [
      { method: 'POST', path: '/v1/sessions/:id/beliefs', description: 'Record a belief' },
      { method: 'GET', path: '/v1/sessions/:id/beliefs', description: 'List session beliefs' },
      { method: 'PUT', path: '/v1/beliefs/:id', description: 'Update belief confidence' },
      { method: 'DELETE', path: '/v1/beliefs/:id', description: 'Retract a belief' },
    ],
  },
  {
    category: 'Inferences',
    items: [
      { method: 'POST', path: '/v1/sessions/:id/inferences', description: 'Record an inference' },
      { method: 'GET', path: '/v1/sessions/:id/inferences', description: 'List session inferences' },
      { method: 'GET', path: '/v1/inferences/:id/chain', description: 'Get inference chain' },
    ],
  },
  {
    category: 'Decisions',
    items: [
      { method: 'POST', path: '/v1/sessions/:id/decisions', description: 'Record a decision' },
      { method: 'GET', path: '/v1/sessions/:id/decisions', description: 'List session decisions' },
      { method: 'GET', path: '/v1/decisions/:id/explain', description: 'Get decision explanation' },
    ],
  },
  {
    category: 'Constraints',
    items: [
      { method: 'POST', path: '/v1/constraints', description: 'Create a constraint' },
      { method: 'GET', path: '/v1/constraints', description: 'List all constraints' },
      { method: 'PUT', path: '/v1/constraints/:id', description: 'Update a constraint' },
      { method: 'DELETE', path: '/v1/constraints/:id', description: 'Delete a constraint' },
      { method: 'POST', path: '/v1/constraints/:id/validate', description: 'Validate against constraint' },
    ],
  },
  {
    category: 'Neural Graph',
    items: [
      { method: 'GET', path: '/v1/sessions/:id/graph', description: 'Get session reasoning graph' },
      { method: 'GET', path: '/v1/sessions/:id/graph/export', description: 'Export graph as JSON/SVG' },
      { method: 'GET', path: '/v1/sessions/:id/timeline', description: 'Get reasoning timeline' },
    ],
  },
  {
    category: 'Agents',
    items: [
      { method: 'POST', path: '/v1/agents', description: 'Register an agent' },
      { method: 'GET', path: '/v1/agents', description: 'List all agents' },
      { method: 'GET', path: '/v1/agents/:id', description: 'Get agent details' },
      { method: 'PUT', path: '/v1/agents/:id', description: 'Update agent configuration' },
      { method: 'DELETE', path: '/v1/agents/:id', description: 'Remove an agent' },
    ],
  },
]

const methodColors: Record<string, string> = {
  GET: 'bg-blue-500/20 text-blue-400',
  POST: 'bg-green-500/20 text-green-400',
  PUT: 'bg-amber-500/20 text-amber-400',
  DELETE: 'bg-red-500/20 text-red-400',
}

export default function ApiReferencePage() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">API Reference</h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Complete reference for the Velarix REST API. Base URL:{' '}
              <code className="px-2 py-0.5 rounded bg-secondary font-mono text-sm">https://api.velarix.dev</code>
            </p>
          </div>

          {/* Authentication */}
          <div className="mb-12 p-6 rounded-xl border border-border/50 bg-card/50">
            <h2 className="text-xl font-semibold mb-3">Authentication</h2>
            <p className="text-muted-foreground mb-4">
              All API requests require authentication using your API key in the Authorization header.
            </p>
            <div className="p-4 rounded-lg bg-background font-mono text-sm overflow-x-auto">
              <span className="text-muted-foreground">Authorization:</span>{' '}
              <span className="text-primary">Bearer vlx_sk_your_api_key</span>
            </div>
          </div>

          {/* Endpoints */}
          <div className="space-y-8">
            {endpoints.map((category) => (
              <div key={category.category}>
                <button
                  onClick={() => setActiveCategory(activeCategory === category.category ? null : category.category)}
                  className="flex items-center justify-between w-full p-4 rounded-xl border border-border/50 bg-card/50 hover:border-primary/30 transition-all"
                >
                  <h2 className="text-xl font-semibold">{category.category}</h2>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">
                      {category.items.length} endpoints
                    </span>
                    <svg
                      className={cn(
                        'w-5 h-5 text-muted-foreground transition-transform',
                        activeCategory === category.category && 'rotate-180'
                      )}
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </button>

                {activeCategory === category.category && (
                  <div className="mt-2 space-y-2">
                    {category.items.map((endpoint, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-4 p-4 rounded-lg border border-border/30 bg-card/30 hover:border-primary/20 transition-all cursor-pointer"
                      >
                        <span className={cn('px-2 py-1 rounded text-xs font-mono font-medium', methodColors[endpoint.method])}>
                          {endpoint.method}
                        </span>
                        <code className="font-mono text-sm text-foreground">{endpoint.path}</code>
                        <span className="text-sm text-muted-foreground flex-1">{endpoint.description}</span>
                        <svg className="w-4 h-4 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Rate Limits */}
          <div className="mt-12 p-6 rounded-xl border border-border/50 bg-card/50">
            <h2 className="text-xl font-semibold mb-3">Rate Limits</h2>
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-background">
                <p className="text-2xl font-bold text-primary">1,000</p>
                <p className="text-sm text-muted-foreground">Requests per minute (Starter)</p>
              </div>
              <div className="p-4 rounded-lg bg-background">
                <p className="text-2xl font-bold text-primary">10,000</p>
                <p className="text-sm text-muted-foreground">Requests per minute (Pro)</p>
              </div>
              <div className="p-4 rounded-lg bg-background">
                <p className="text-2xl font-bold text-primary">Custom</p>
                <p className="text-sm text-muted-foreground">Requests per minute (Enterprise)</p>
              </div>
            </div>
          </div>

          {/* SDKs */}
          <div className="mt-12 text-center">
            <p className="text-muted-foreground">
              Prefer using our SDKs?{' '}
              <Link href="/docs" className="text-primary hover:underline">
                Check the documentation
              </Link>{' '}
              for Python and JavaScript clients.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
