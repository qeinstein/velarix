'use client'

import { HeroSection } from '@/components/landing/hero-section'
import { FeaturesSection } from '@/components/landing/features-section'
import { CodeSection } from '@/components/landing/code-section'
import { UseCasesSection } from '@/components/landing/use-cases-section'
import { CTASection } from '@/components/landing/cta-section'
import { Navigation } from '@/components/landing/navigation'
import { ParticleField } from '@/components/landing/particle-field'
import { Footer } from '@/components/landing/footer'

export default function LandingPage() {
  return (
    <div className="relative min-h-screen overflow-x-hidden">
      {/* Ambient background effects */}
      <div className="fixed inset-0 pointer-events-none">
        <ParticleField />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,oklch(0.20_0.08_195/0.15),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,oklch(0.20_0.10_160/0.10),transparent_50%)]" />
      </div>
      
      <Navigation />
      
      <main className="relative z-10">
        <HeroSection />
        <FeaturesSection />
        <CodeSection />
        <UseCasesSection />
        <CTASection />
      </main>
      
      <Footer />
    </div>
  )
}
