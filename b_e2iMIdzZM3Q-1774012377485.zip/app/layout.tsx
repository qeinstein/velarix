import type { Metadata, Viewport } from 'next'
import { Inter, JetBrains_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({ 
  subsets: ["latin"],
  variable: '--font-jetbrains',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Velarix | AI Agent Reasoning & Audit Layer',
  description: 'Because your agents need to explain every decision. The reasoning and audit layer for AI agents in regulated industries.',
  generator: 'v0.app',
  keywords: ['AI', 'agents', 'reasoning', 'audit', 'compliance', 'healthcare', 'legal', 'finance', 'explainable AI'],
  authors: [{ name: 'Velarix' }],
  openGraph: {
    title: 'Velarix | AI Agent Reasoning & Audit Layer',
    description: 'Because your agents need to explain every decision.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Velarix | AI Agent Reasoning & Audit Layer',
    description: 'Because your agents need to explain every decision.',
  },
}

export const viewport: Viewport = {
  themeColor: '#0a1628',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} ${jetbrainsMono.variable} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
