'use client'

import Link from 'next/link'
import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'

const posts = [
  {
    slug: 'announcing-velarix',
    title: 'Announcing Velarix: The Reasoning Layer for AI Agents',
    excerpt: 'Today we\'re excited to announce Velarix, the reasoning and audit layer that helps AI agents explain every decision they make.',
    author: 'Sarah Chen',
    role: 'Co-founder & CEO',
    date: 'March 15, 2026',
    readTime: '5 min read',
    category: 'Announcement',
    featured: true,
  },
  {
    slug: 'why-explainable-ai-matters',
    title: 'Why Explainable AI Matters for Regulated Industries',
    excerpt: 'Healthcare, legal, and finance are adopting AI rapidly. But without explainability, these powerful tools remain black boxes that regulators can\'t trust.',
    author: 'Dr. Michael Torres',
    role: 'Head of Research',
    date: 'March 12, 2026',
    readTime: '8 min read',
    category: 'Industry',
    featured: false,
  },
  {
    slug: 'neural-graph-deep-dive',
    title: 'Deep Dive: How the Neural Graph Visualizes Reasoning',
    excerpt: 'Learn how Velarix\'s neural graph captures causal relationships between beliefs, inferences, and decisions in real-time.',
    author: 'Alex Kim',
    role: 'Engineering Lead',
    date: 'March 8, 2026',
    readTime: '12 min read',
    category: 'Technical',
    featured: false,
  },
  {
    slug: 'constraint-based-safety',
    title: 'Constraint-Based Safety: A New Paradigm for AI Guardrails',
    excerpt: 'Moving beyond simple prompt engineering, constraints provide deterministic safety guarantees for AI agent behavior.',
    author: 'Dr. Michael Torres',
    role: 'Head of Research',
    date: 'March 1, 2026',
    readTime: '10 min read',
    category: 'Research',
    featured: false,
  },
  {
    slug: 'building-hipaa-compliant-agents',
    title: 'Building HIPAA-Compliant AI Agents with Velarix',
    excerpt: 'A practical guide to implementing AI agents in healthcare while maintaining full regulatory compliance.',
    author: 'Sarah Chen',
    role: 'Co-founder & CEO',
    date: 'February 25, 2026',
    readTime: '7 min read',
    category: 'Guide',
    featured: false,
  },
  {
    slug: 'real-time-monitoring-patterns',
    title: 'Real-Time Monitoring Patterns for Production AI Systems',
    excerpt: 'Best practices for monitoring AI agent behavior in production, with examples from our enterprise customers.',
    author: 'Alex Kim',
    role: 'Engineering Lead',
    date: 'February 18, 2026',
    readTime: '9 min read',
    category: 'Technical',
    featured: false,
  },
]

const categoryColors: Record<string, string> = {
  Announcement: 'bg-primary/20 text-primary',
  Industry: 'bg-blue-500/20 text-blue-400',
  Technical: 'bg-purple-500/20 text-purple-400',
  Research: 'bg-accent/20 text-accent',
  Guide: 'bg-amber-500/20 text-amber-400',
}

export default function BlogPage() {
  const featuredPost = posts.find((p) => p.featured)
  const otherPosts = posts.filter((p) => !p.featured)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">Blog</h1>
            <p className="text-lg text-muted-foreground">
              Insights on explainable AI, compliance, and the future of autonomous agents.
            </p>
          </div>

          {/* Featured Post */}
          {featuredPost && (
            <Link
              href={`/blog/${featuredPost.slug}`}
              className="group block mb-16 p-8 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-card/50 to-accent/10 hover:border-primary/50 transition-all"
            >
              <span className={`inline-flex text-xs px-2 py-1 rounded-full mb-4 ${categoryColors[featuredPost.category]}`}>
                {featuredPost.category}
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold mb-3 group-hover:text-primary transition-colors">
                {featuredPost.title}
              </h2>
              <p className="text-muted-foreground mb-6 max-w-2xl">
                {featuredPost.excerpt}
              </p>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="text-sm font-medium text-primary">
                    {featuredPost.author.split(' ').map((n) => n[0]).join('')}
                  </span>
                </div>
                <div>
                  <p className="text-sm font-medium">{featuredPost.author}</p>
                  <p className="text-xs text-muted-foreground">{featuredPost.date} · {featuredPost.readTime}</p>
                </div>
              </div>
            </Link>
          )}

          {/* Other Posts */}
          <div className="grid md:grid-cols-2 gap-6">
            {otherPosts.map((post) => (
              <Link
                key={post.slug}
                href={`/blog/${post.slug}`}
                className="group flex flex-col p-6 rounded-xl border border-border/50 bg-card/50 hover:border-primary/30 hover:bg-card transition-all"
              >
                <span className={`self-start text-xs px-2 py-0.5 rounded-full mb-3 ${categoryColors[post.category]}`}>
                  {post.category}
                </span>
                <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                  {post.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 flex-1">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{post.author}</span>
                  <span>{post.date} · {post.readTime}</span>
                </div>
              </Link>
            ))}
          </div>

          {/* Newsletter */}
          <div className="mt-16 p-8 rounded-2xl border border-border/50 bg-card/50 text-center">
            <h3 className="text-xl font-semibold mb-2">Subscribe to our newsletter</h3>
            <p className="text-muted-foreground mb-6">
              Get the latest posts delivered to your inbox.
            </p>
            <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                placeholder="you@example.com"
                className="flex-1 h-10 px-4 rounded-lg bg-background border border-border/50 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
              <button
                type="submit"
                className="h-10 px-6 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
