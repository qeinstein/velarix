'use client'

import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold tracking-tight mb-4">Terms of Service</h1>
          <p className="text-muted-foreground mb-8">Last updated: March 1, 2026</p>

          <div className="prose prose-invert max-w-none space-y-8">
            <section>
              <h2 className="text-2xl font-semibold mb-4">1. Agreement to Terms</h2>
              <p className="text-muted-foreground leading-relaxed">
                By accessing or using Velarix's services ("Services"), you agree to be bound by these 
                Terms of Service ("Terms"). If you do not agree to these Terms, you may not access or 
                use the Services. If you are using the Services on behalf of an organization, you 
                represent that you have the authority to bind that organization to these Terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">2. Description of Services</h2>
              <p className="text-muted-foreground leading-relaxed">
                Velarix provides a reasoning and audit layer for AI agents, including APIs, dashboards, 
                and tools for tracking beliefs, inferences, decisions, and constraints. The Services 
                enable you to monitor, audit, and explain the reasoning of AI systems in regulated industries.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">3. Account Registration</h2>
              <p className="text-muted-foreground leading-relaxed">
                To use certain features of the Services, you must register for an account. You agree to:
              </p>
              <ul className="list-disc list-inside text-muted-foreground space-y-2 mt-2">
                <li>Provide accurate and complete information</li>
                <li>Maintain the security of your account credentials</li>
                <li>Promptly update any changes to your information</li>
                <li>Accept responsibility for all activities under your account</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">4. Acceptable Use</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                You agree not to use the Services to:
              </p>
              <ul className="list-disc list-inside text-muted-foreground space-y-2">
                <li>Violate any applicable laws or regulations</li>
                <li>Infringe on intellectual property rights</li>
                <li>Transmit malicious code or interfere with the Services</li>
                <li>Attempt unauthorized access to any systems</li>
                <li>Use the Services for any illegal or harmful purpose</li>
                <li>Reverse engineer or decompile the Services</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">5. Data Processing</h2>
              <p className="text-muted-foreground leading-relaxed">
                You retain ownership of all data you submit to the Services ("Customer Data"). 
                You grant Velarix a limited license to process Customer Data solely to provide 
                the Services. For customers subject to data protection regulations (e.g., HIPAA, GDPR), 
                additional data processing agreements may apply.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">6. Payment Terms</h2>
              <p className="text-muted-foreground leading-relaxed">
                Paid subscriptions are billed in advance on a monthly or annual basis. You authorize 
                us to charge your payment method for all fees. Fees are non-refundable except as 
                required by law. We may change pricing with 30 days' notice. Failure to pay may 
                result in suspension or termination of your account.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">7. Service Level Agreement</h2>
              <p className="text-muted-foreground leading-relaxed">
                For Pro and Enterprise customers, Velarix provides a 99.9% uptime guarantee. 
                Details of service level commitments and credits are outlined in your subscription 
                agreement. Scheduled maintenance windows are excluded from uptime calculations.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">8. Intellectual Property</h2>
              <p className="text-muted-foreground leading-relaxed">
                The Services and all related technology, content, and materials are owned by 
                Velarix and protected by intellectual property laws. You receive no rights other 
                than the limited license to use the Services as described in these Terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">9. Limitation of Liability</h2>
              <p className="text-muted-foreground leading-relaxed">
                TO THE MAXIMUM EXTENT PERMITTED BY LAW, VELARIX SHALL NOT BE LIABLE FOR ANY INDIRECT, 
                INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF PROFITS OR 
                REVENUES. OUR TOTAL LIABILITY SHALL NOT EXCEED THE AMOUNTS PAID BY YOU IN THE 
                TWELVE MONTHS PRECEDING THE CLAIM.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">10. Termination</h2>
              <p className="text-muted-foreground leading-relaxed">
                Either party may terminate these Terms upon 30 days' written notice. We may suspend 
                or terminate your access immediately for breach of these Terms or non-payment. 
                Upon termination, you may request export of your Customer Data within 30 days.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">11. Governing Law</h2>
              <p className="text-muted-foreground leading-relaxed">
                These Terms shall be governed by the laws of the State of California without regard 
                to conflict of law principles. Any disputes shall be resolved in the courts of 
                San Francisco County, California.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">12. Changes to Terms</h2>
              <p className="text-muted-foreground leading-relaxed">
                We may update these Terms from time to time. Material changes will be communicated 
                via email or through the Services. Continued use after changes constitutes acceptance 
                of the updated Terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Contact</h2>
              <p className="text-muted-foreground leading-relaxed">
                Questions about these Terms should be directed to:
              </p>
              <p className="text-muted-foreground mt-2">
                Email: <a href="mailto:legal@velarix.dev" className="text-primary hover:underline">legal@velarix.dev</a><br />
                Address: 548 Market St, Suite 12345, San Francisco, CA 94104
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
