'use client'

import Link from 'next/link'
import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'

const certifications = [
  {
    name: 'SOC 2 Type II',
    description: 'Annual audit of security, availability, and confidentiality controls',
    status: 'Certified',
    date: 'January 2026',
  },
  {
    name: 'HIPAA',
    description: 'Health Insurance Portability and Accountability Act compliance',
    status: 'Compliant',
    date: 'December 2025',
  },
  {
    name: 'GDPR',
    description: 'General Data Protection Regulation compliance for EU data',
    status: 'Compliant',
    date: 'November 2025',
  },
  {
    name: 'ISO 27001',
    description: 'Information security management system certification',
    status: 'In Progress',
    date: 'Expected Q2 2026',
  },
]

const securityFeatures = [
  {
    title: 'Encryption at Rest',
    description: 'All data is encrypted using AES-256 encryption at rest.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
      </svg>
    ),
  },
  {
    title: 'Encryption in Transit',
    description: 'TLS 1.3 for all API communications and data transfers.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
      </svg>
    ),
  },
  {
    title: 'Access Control',
    description: 'Role-based access control with principle of least privilege.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
      </svg>
    ),
  },
  {
    title: 'Audit Logging',
    description: 'Comprehensive audit logs for all system access and changes.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
      </svg>
    ),
  },
  {
    title: 'Data Isolation',
    description: 'Customer data is logically isolated in multi-tenant architecture.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
      </svg>
    ),
  },
  {
    title: 'Penetration Testing',
    description: 'Regular third-party penetration testing and vulnerability assessments.',
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
  },
]

export default function SecurityPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">Security</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Enterprise-grade security for regulated industries. Your data is protected by 
              industry-leading security practices and compliance certifications.
            </p>
          </div>

          {/* Certifications */}
          <div className="mb-16">
            <h2 className="text-2xl font-semibold mb-6">Compliance & Certifications</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {certifications.map((cert) => (
                <div key={cert.name} className="p-6 rounded-xl border border-border/50 bg-card/50">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg font-semibold">{cert.name}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      cert.status === 'Certified' || cert.status === 'Compliant'
                        ? 'bg-accent/20 text-accent'
                        : 'bg-amber-500/20 text-amber-400'
                    }`}>
                      {cert.status}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{cert.description}</p>
                  <p className="text-xs text-muted-foreground">{cert.date}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Security Features */}
          <div className="mb-16">
            <h2 className="text-2xl font-semibold mb-6">Security Features</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {securityFeatures.map((feature) => (
                <div key={feature.title} className="p-6 rounded-xl border border-border/50 bg-card/50">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary inline-flex mb-3">
                    {feature.icon}
                  </div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Infrastructure */}
          <div className="mb-16 p-8 rounded-2xl border border-border/50 bg-card/50">
            <h2 className="text-2xl font-semibold mb-4">Infrastructure</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium mb-2">Cloud Provider</h3>
                <p className="text-sm text-muted-foreground">
                  Hosted on AWS with SOC 2 compliant data centers. Multi-region 
                  deployment with automatic failover and 99.99% uptime SLA.
                </p>
              </div>
              <div>
                <h3 className="font-medium mb-2">Data Residency</h3>
                <p className="text-sm text-muted-foreground">
                  Choose your data region: US (Virginia), EU (Frankfurt), or APAC (Singapore). 
                  Data never leaves your selected region.
                </p>
              </div>
              <div>
                <h3 className="font-medium mb-2">Backup & Recovery</h3>
                <p className="text-sm text-muted-foreground">
                  Automated daily backups with point-in-time recovery. 
                  30-day retention with geo-redundant storage.
                </p>
              </div>
              <div>
                <h3 className="font-medium mb-2">Incident Response</h3>
                <p className="text-sm text-muted-foreground">
                  24/7 security monitoring with automated threat detection. 
                  Dedicated incident response team with 15-minute SLA.
                </p>
              </div>
            </div>
          </div>

          {/* Bug Bounty */}
          <div className="mb-16 p-8 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-card/50 to-accent/10">
            <h2 className="text-2xl font-semibold mb-4">Bug Bounty Program</h2>
            <p className="text-muted-foreground mb-4">
              We maintain a responsible disclosure program for security researchers. 
              Report vulnerabilities to our security team and earn rewards.
            </p>
            <Link
              href="mailto:security@velarix.dev"
              className="text-primary hover:underline"
            >
              security@velarix.dev
            </Link>
          </div>

          {/* Contact */}
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">Questions about security?</h3>
            <p className="text-muted-foreground mb-4">
              Our security team is happy to discuss our practices in detail.
            </p>
            <Link
              href="/contact"
              className="inline-flex h-10 px-6 items-center justify-center rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
            >
              Contact Security Team
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
