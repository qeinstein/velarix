'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'

const sections = [
  {
    title: 'Getting Started',
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
    items: [
      { title: 'Introduction', href: '/docs/introduction', description: 'Learn what Velarix is and how it works' },
      { title: 'Quick Start', href: '/docs/quickstart', description: 'Get up and running in 5 minutes' },
      { title: 'Core Concepts', href: '/docs/concepts', description: 'Understand beliefs, inferences, and constraints' },
      { title: 'Architecture', href: '/docs/architecture', description: 'How Velarix integrates with your agents' },
    ],
  },
  {
    title: 'Integration',
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z" />
      </svg>
    ),
    items: [
      { title: 'Python SDK', href: '/docs/sdk-python', description: 'Official Python client library' },
      { title: 'JavaScript SDK', href: '/docs/sdk-javascript', description: 'Official JavaScript/TypeScript client' },
      { title: 'REST API', href: '/api-reference', description: 'HTTP API reference documentation' },
      { title: 'Webhooks', href: '/docs/webhooks', description: 'Real-time event notifications' },
    ],
  },
  {
    title: 'Features',
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
      </svg>
    ),
    items: [
      { title: 'Neural Graph', href: '/docs/neural-graph', description: 'Visualize reasoning chains' },
      { title: 'Constraints', href: '/docs/constraints', description: 'Define rules your agents must follow' },
      { title: 'Audit Logs', href: '/docs/audit-logs', description: 'Complete reasoning history' },
      { title: 'Real-time Monitoring', href: '/docs/monitoring', description: 'Live session tracking' },
    ],
  },
  {
    title: 'Compliance',
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
    items: [
      { title: 'HIPAA', href: '/docs/hipaa', description: 'Healthcare compliance guide' },
      { title: 'SOC2', href: '/docs/soc2', description: 'Security compliance details' },
      { title: 'GDPR', href: '/docs/gdpr', description: 'Data protection compliance' },
      { title: 'Data Retention', href: '/docs/data-retention', description: 'Log retention policies' },
    ],
  },
]

export default function DocsPage() {
  const [search, setSearch] = useState('')

  const filteredSections = sections.map((section) => ({
    ...section,
    items: section.items.filter(
      (item) =>
        search === '' ||
        item.title.toLowerCase().includes(search.toLowerCase()) ||
        item.description.toLowerCase().includes(search.toLowerCase())
    ),
  })).filter((section) => section.items.length > 0)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">Documentation</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to integrate Velarix into your AI systems.
            </p>
          </div>

          {/* Search */}
          <div className="max-w-xl mx-auto mb-16">
            <div className="relative">
              <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <Input
                placeholder="Search documentation..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-12 h-12 text-lg bg-card/50 border-border/50"
              />
              <kbd className="absolute right-4 top-1/2 -translate-y-1/2 hidden sm:inline-flex items-center gap-1 px-2 py-0.5 text-xs font-mono text-muted-foreground bg-secondary rounded">
                <span className="text-xs">Ctrl</span>K
              </kbd>
            </div>
          </div>

          {/* Sections */}
          <div className="grid md:grid-cols-2 gap-8">
            {filteredSections.map((section) => (
              <div key={section.title} className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary">
                    {section.icon}
                  </div>
                  <h2 className="text-xl font-semibold">{section.title}</h2>
                </div>
                <div className="space-y-2">
                  {section.items.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="block p-4 rounded-xl border border-border/50 bg-card/50 hover:border-primary/30 hover:bg-card transition-all"
                    >
                      <h3 className="font-medium mb-1">{item.title}</h3>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {filteredSections.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No results found for "{search}"</p>
            </div>
          )}

          {/* Help */}
          <div className="mt-16 p-8 rounded-2xl border border-border/50 bg-card/30 text-center">
            <h3 className="text-xl font-semibold mb-2">Need help?</h3>
            <p className="text-muted-foreground mb-4">
              Can't find what you're looking for? Our team is here to help.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/contact" className="text-primary hover:underline text-sm">
                Contact Support
              </Link>
              <Link href="https://github.com/velarix/velarix" className="text-primary hover:underline text-sm">
                GitHub Discussions
              </Link>
              <Link href="/guides" className="text-primary hover:underline text-sm">
                Browse Guides
              </Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
