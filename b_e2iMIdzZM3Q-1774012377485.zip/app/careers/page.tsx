'use client'

import Link from 'next/link'
import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'
import { cn } from '@/lib/utils'

const departments = [
  {
    name: 'Engineering',
    positions: [
      {
        title: 'Senior Backend Engineer',
        location: 'San Francisco / Remote',
        type: 'Full-time',
        description: 'Build the core reasoning infrastructure that powers Velarix.',
      },
      {
        title: 'Senior Frontend Engineer',
        location: 'San Francisco / Remote',
        type: 'Full-time',
        description: 'Create beautiful, responsive interfaces for our neural graph visualization.',
      },
      {
        title: 'Staff ML Engineer',
        location: 'San Francisco',
        type: 'Full-time',
        description: 'Design and implement causal inference algorithms at scale.',
      },
      {
        title: 'Platform Engineer',
        location: 'San Francisco / Remote',
        type: 'Full-time',
        description: 'Build the infrastructure that serves millions of reasoning events.',
      },
    ],
  },
  {
    name: 'Research',
    positions: [
      {
        title: 'Research Scientist - Explainable AI',
        location: 'San Francisco',
        type: 'Full-time',
        description: 'Advance the state of the art in interpretable machine learning.',
      },
      {
        title: 'Applied Research Engineer',
        location: 'San Francisco / Remote',
        type: 'Full-time',
        description: 'Bridge research and production with novel AI systems.',
      },
    ],
  },
  {
    name: 'Product',
    positions: [
      {
        title: 'Product Manager',
        location: 'San Francisco',
        type: 'Full-time',
        description: 'Define the product roadmap for enterprise AI reasoning tools.',
      },
      {
        title: 'Product Designer',
        location: 'San Francisco / Remote',
        type: 'Full-time',
        description: 'Design intuitive experiences for complex AI systems.',
      },
    ],
  },
  {
    name: 'Go-to-Market',
    positions: [
      {
        title: 'Enterprise Account Executive',
        location: 'San Francisco / New York',
        type: 'Full-time',
        description: 'Close deals with Fortune 500 healthcare, legal, and financial institutions.',
      },
      {
        title: 'Developer Advocate',
        location: 'Remote',
        type: 'Full-time',
        description: 'Build community and create content that helps developers succeed.',
      },
    ],
  },
]

const benefits = [
  { icon: '💰', title: 'Competitive Salary', description: 'Top-of-market compensation' },
  { icon: '📈', title: 'Equity', description: 'Meaningful ownership stake' },
  { icon: '🏥', title: 'Health Benefits', description: '100% covered medical, dental, vision' },
  { icon: '🏖️', title: 'Unlimited PTO', description: 'Take the time you need' },
  { icon: '🏠', title: 'Remote Flexible', description: 'Work from anywhere' },
  { icon: '📚', title: 'Learning Budget', description: '$5k annual for growth' },
]

export default function CareersPage() {
  const totalPositions = departments.reduce((acc, dept) => acc + dept.positions.length, 0)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-5xl mx-auto">
          {/* Hero */}
          <div className="text-center mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">
              <span className="text-balance">
                Join us in making AI{' '}
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  explainable
                </span>
              </span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-6">
              We're building the infrastructure that lets AI agents explain their decisions. 
              Join a team of world-class researchers and engineers tackling one of AI's hardest problems.
            </p>
            <p className="text-sm text-accent">
              {totalPositions} open positions across {departments.length} teams
            </p>
          </div>

          {/* Benefits */}
          <div className="mb-16">
            <h2 className="text-2xl font-semibold mb-6 text-center">Why Velarix?</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {benefits.map((benefit) => (
                <div key={benefit.title} className="p-4 rounded-xl border border-border/50 bg-card/50 flex items-start gap-3">
                  <span className="text-2xl">{benefit.icon}</span>
                  <div>
                    <h3 className="font-medium">{benefit.title}</h3>
                    <p className="text-sm text-muted-foreground">{benefit.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Open Positions */}
          <div className="space-y-12">
            {departments.map((dept) => (
              <div key={dept.name}>
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  {dept.name}
                  <span className="text-sm font-normal text-muted-foreground">
                    ({dept.positions.length} positions)
                  </span>
                </h2>
                <div className="space-y-3">
                  {dept.positions.map((position) => (
                    <Link
                      key={position.title}
                      href={`/careers/${position.title.toLowerCase().replace(/\s+/g, '-')}`}
                      className="group flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl border border-border/50 bg-card/50 hover:border-primary/30 hover:bg-card transition-all"
                    >
                      <div className="mb-2 sm:mb-0">
                        <h3 className="font-medium group-hover:text-primary transition-colors">
                          {position.title}
                        </h3>
                        <p className="text-sm text-muted-foreground">{position.description}</p>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <span className="text-muted-foreground">{position.location}</span>
                        <span className="px-2 py-0.5 rounded-full bg-accent/20 text-accent text-xs">
                          {position.type}
                        </span>
                        <svg className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Don't see your role? */}
          <div className="mt-16 p-8 rounded-2xl border border-border/50 bg-card/50 text-center">
            <h3 className="text-xl font-semibold mb-2">Don't see your role?</h3>
            <p className="text-muted-foreground mb-4">
              We're always looking for exceptional people. Send us your resume and tell us why you'd be a great fit.
            </p>
            <Link
              href="mailto:careers@velarix.dev"
              className="text-primary hover:underline"
            >
              careers@velarix.dev
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
