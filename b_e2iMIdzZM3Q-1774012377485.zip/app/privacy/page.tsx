'use client'

import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold tracking-tight mb-4">Privacy Policy</h1>
          <p className="text-muted-foreground mb-8">Last updated: March 1, 2026</p>

          <div className="prose prose-invert max-w-none space-y-8">
            <section>
              <h2 className="text-2xl font-semibold mb-4">Introduction</h2>
              <p className="text-muted-foreground leading-relaxed">
                Velarix, Inc. ("Velarix," "we," "us," or "our") is committed to protecting your privacy. 
                This Privacy Policy explains how we collect, use, disclose, and safeguard your information 
                when you use our reasoning and audit platform for AI agents.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Information We Collect</h2>
              <h3 className="text-lg font-medium mb-2">Information You Provide</h3>
              <ul className="list-disc list-inside text-muted-foreground space-y-2">
                <li>Account information (name, email, company)</li>
                <li>Payment information (processed securely via Stripe)</li>
                <li>API keys and configuration data</li>
                <li>Support communications</li>
              </ul>

              <h3 className="text-lg font-medium mt-4 mb-2">Information We Collect Automatically</h3>
              <ul className="list-disc list-inside text-muted-foreground space-y-2">
                <li>Usage data and API call logs</li>
                <li>Device and browser information</li>
                <li>IP addresses</li>
                <li>Cookies and similar tracking technologies</li>
              </ul>

              <h3 className="text-lg font-medium mt-4 mb-2">AI Agent Data</h3>
              <p className="text-muted-foreground leading-relaxed">
                When you integrate Velarix with your AI agents, we process reasoning data including 
                beliefs, inferences, decisions, and constraints. This data is used solely to provide 
                our service and is never used to train machine learning models or shared with third parties.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">How We Use Your Information</h2>
              <ul className="list-disc list-inside text-muted-foreground space-y-2">
                <li>Provide, maintain, and improve our services</li>
                <li>Process transactions and send related information</li>
                <li>Send technical notices, updates, and support messages</li>
                <li>Respond to comments, questions, and customer service requests</li>
                <li>Monitor and analyze usage patterns and trends</li>
                <li>Detect, prevent, and address technical issues</li>
                <li>Comply with legal obligations</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Data Retention</h2>
              <p className="text-muted-foreground leading-relaxed">
                We retain your data for as long as your account is active or as needed to provide services. 
                Reasoning data retention periods depend on your subscription plan (7 days for Starter, 
                90 days for Pro, unlimited for Enterprise). You may request deletion of your data at any time.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Data Security</h2>
              <p className="text-muted-foreground leading-relaxed">
                We implement industry-standard security measures including encryption at rest (AES-256) 
                and in transit (TLS 1.3), regular security audits, and access controls. We are SOC 2 Type II 
                certified and HIPAA compliant for healthcare customers.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Your Rights</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Depending on your location, you may have rights including:
              </p>
              <ul className="list-disc list-inside text-muted-foreground space-y-2">
                <li>Access to your personal data</li>
                <li>Correction of inaccurate data</li>
                <li>Deletion of your data</li>
                <li>Data portability</li>
                <li>Objection to processing</li>
                <li>Withdrawal of consent</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">International Transfers</h2>
              <p className="text-muted-foreground leading-relaxed">
                We process data in the United States and other countries. For EU customers, we offer 
                data residency in our Frankfurt region and comply with GDPR requirements including 
                Standard Contractual Clauses for data transfers.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Changes to This Policy</h2>
              <p className="text-muted-foreground leading-relaxed">
                We may update this Privacy Policy from time to time. We will notify you of any material 
                changes by posting the new policy on this page and updating the "Last updated" date.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
              <p className="text-muted-foreground leading-relaxed">
                If you have questions about this Privacy Policy, please contact us at:
              </p>
              <p className="text-muted-foreground mt-2">
                Email: <a href="mailto:privacy@velarix.dev" className="text-primary hover:underline">privacy@velarix.dev</a><br />
                Address: 548 Market St, Suite 12345, San Francisco, CA 94104
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
