'use client'

import { useState } from 'react'
import { NeuralGraph } from '@/components/dashboard/neural-graph'
import { GraphControls } from '@/components/dashboard/graph-controls'
import { FactInspector } from '@/components/dashboard/fact-inspector'

export default function GraphPage() {
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null)
  const [isPlaying, setIsPlaying] = useState(true)
  const [playbackSpeed, setPlaybackSpeed] = useState(1)
  const [currentTime, setCurrentTime] = useState(0)
  const [zoom, setZoom] = useState(1)

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col rounded-xl overflow-hidden border border-border/50 bg-card/30 backdrop-blur-sm">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-secondary/30">
        <div className="flex items-center gap-4">
          <h2 className="font-semibold">Neural Graph Visualizer</h2>
          <select className="h-8 px-3 rounded-lg bg-secondary/50 border border-border/50 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50">
            <option>Session: sess_8x7k2m</option>
            <option>Session: sess_9p3n1q</option>
            <option>Session: sess_2w8j5r</option>
          </select>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setZoom(z => Math.max(0.5, z - 0.1))}
            className="w-8 h-8 rounded-lg bg-secondary/50 border border-border/50 flex items-center justify-center hover:bg-secondary/70 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
            </svg>
          </button>
          <span className="text-sm text-muted-foreground w-12 text-center">{Math.round(zoom * 100)}%</span>
          <button 
            onClick={() => setZoom(z => Math.min(2, z + 0.1))}
            className="w-8 h-8 rounded-lg bg-secondary/50 border border-border/50 flex items-center justify-center hover:bg-secondary/70 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
          </button>
          <button 
            onClick={() => setZoom(1)}
            className="ml-2 px-3 h-8 rounded-lg bg-secondary/50 border border-border/50 text-sm hover:bg-secondary/70 transition-colors"
          >
            Reset
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex relative overflow-hidden">
        {/* Graph Canvas */}
        <div className="flex-1 relative">
          <NeuralGraph 
            zoom={zoom}
            onNodeSelect={setSelectedNodeId}
            selectedNodeId={selectedNodeId}
            isPlaying={isPlaying}
          />
        </div>

        {/* Fact Inspector Panel */}
        <FactInspector 
          nodeId={selectedNodeId} 
          onClose={() => setSelectedNodeId(null)} 
        />
      </div>

      {/* Timeline Controls */}
      <GraphControls
        isPlaying={isPlaying}
        onPlayPause={() => setIsPlaying(!isPlaying)}
        playbackSpeed={playbackSpeed}
        onSpeedChange={setPlaybackSpeed}
        currentTime={currentTime}
        onTimeChange={setCurrentTime}
        totalDuration={100}
      />
    </div>
  )
}
