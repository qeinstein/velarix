'use client'

import { MetricCards } from '@/components/dashboard/metric-cards'
import { ActiveSessions } from '@/components/dashboard/active-sessions'
import { JournalFeed } from '@/components/dashboard/journal-feed'
import { SystemActivity } from '@/components/dashboard/system-activity'

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Mission Control</h1>
          <p className="text-muted-foreground">Monitor your AI reasoning system in real time.</p>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="text-muted-foreground">Last synced:</span>
          <span className="font-medium">Just now</span>
          <button className="ml-2 p-1.5 rounded-md hover:bg-secondary/50 transition-colors">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <MetricCards />

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ActiveSessions />
        <JournalFeed />
      </div>

      {/* System Activity Chart */}
      <SystemActivity />
    </div>
  )
}
