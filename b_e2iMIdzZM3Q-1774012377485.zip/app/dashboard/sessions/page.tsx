"use client"

import { useState } from "react"
import { 
  Search, 
  Filter, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  XCircle,
  ChevronRight,
  ArrowUpDown,
  Eye
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

interface Session {
  id: string
  agentId: string
  agentName: string
  status: "success" | "warning" | "error" | "running"
  timestamp: string
  duration: string
  facts: number
  confidence: number
  summary: string
}

const mockSessions: Session[] = [
  {
    id: "sess_7f8a9b2c",
    agentId: "agent_claims",
    agentName: "Claims Processor",
    status: "success",
    timestamp: "2 minutes ago",
    duration: "1.2s",
    facts: 12,
    confidence: 0.94,
    summary: "Approved claim #CLM-2847 for $4,200 based on policy coverage verification"
  },
  {
    id: "sess_3d4e5f6g",
    agentId: "agent_underwriting",
    agentName: "Underwriting Agent",
    status: "warning",
    timestamp: "5 minutes ago",
    duration: "2.8s",
    facts: 24,
    confidence: 0.72,
    summary: "Flagged application for manual review - income verification mismatch"
  },
  {
    id: "sess_8h9i0j1k",
    agentId: "agent_fraud",
    agentName: "Fraud Detection",
    status: "error",
    timestamp: "8 minutes ago",
    duration: "0.8s",
    facts: 8,
    confidence: 0.89,
    summary: "Blocked transaction - multiple constraint violations detected"
  },
  {
    id: "sess_2l3m4n5o",
    agentId: "agent_support",
    agentName: "Support Agent",
    status: "success",
    timestamp: "12 minutes ago",
    duration: "3.1s",
    facts: 18,
    confidence: 0.91,
    summary: "Resolved customer inquiry about policy renewal terms"
  },
  {
    id: "sess_6p7q8r9s",
    agentId: "agent_claims",
    agentName: "Claims Processor",
    status: "running",
    timestamp: "Just now",
    duration: "0.4s",
    facts: 4,
    confidence: 0.0,
    summary: "Processing claim #CLM-2848..."
  },
  {
    id: "sess_0t1u2v3w",
    agentId: "agent_compliance",
    agentName: "Compliance Agent",
    status: "success",
    timestamp: "15 minutes ago",
    duration: "1.8s",
    facts: 32,
    confidence: 0.97,
    summary: "Completed quarterly audit report generation for Q1 2024"
  },
  {
    id: "sess_4x5y6z7a",
    agentId: "agent_underwriting",
    agentName: "Underwriting Agent",
    status: "success",
    timestamp: "18 minutes ago",
    duration: "2.1s",
    facts: 16,
    confidence: 0.88,
    summary: "Approved auto insurance application with standard terms"
  },
  {
    id: "sess_8b9c0d1e",
    agentId: "agent_fraud",
    agentName: "Fraud Detection",
    status: "warning",
    timestamp: "22 minutes ago",
    duration: "1.1s",
    facts: 11,
    confidence: 0.65,
    summary: "Escalated for human review - unusual pattern detected"
  },
]

const statusConfig = {
  success: { 
    icon: CheckCircle2, 
    color: "text-emerald-400", 
    bg: "bg-emerald-400/10",
    label: "Success"
  },
  warning: { 
    icon: AlertCircle, 
    color: "text-amber-400", 
    bg: "bg-amber-400/10",
    label: "Warning"
  },
  error: { 
    icon: XCircle, 
    color: "text-red-400", 
    bg: "bg-red-400/10",
    label: "Error"
  },
  running: { 
    icon: Clock, 
    color: "text-cyan-400", 
    bg: "bg-cyan-400/10",
    label: "Running"
  },
}

function SessionRow({ session }: { session: Session }) {
  const status = statusConfig[session.status]
  const StatusIcon = status.icon

  return (
    <Link 
      href={`/dashboard/graph?session=${session.id}`}
      className="group flex items-center gap-4 rounded-lg border border-[var(--border)] bg-[var(--card)]/50 p-4 transition-all hover:border-[var(--primary)]/30 hover:bg-[var(--card)]"
    >
      <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${status.bg}`}>
        <StatusIcon className={`h-5 w-5 ${status.color}`} />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-medium text-[var(--card-foreground)]">{session.agentName}</span>
          <Badge variant="secondary" className="bg-[var(--muted)] text-[var(--muted-foreground)] text-xs">
            {session.id}
          </Badge>
        </div>
        <p className="mt-1 truncate text-sm text-[var(--muted-foreground)]">
          {session.summary}
        </p>
      </div>

      <div className="hidden items-center gap-6 text-sm lg:flex">
        <div className="text-center">
          <p className="text-[var(--muted-foreground)]">Facts</p>
          <p className="font-medium text-[var(--card-foreground)]">{session.facts}</p>
        </div>
        <div className="text-center">
          <p className="text-[var(--muted-foreground)]">Confidence</p>
          <p className={`font-medium ${session.confidence >= 0.8 ? 'text-emerald-400' : session.confidence >= 0.6 ? 'text-amber-400' : session.confidence > 0 ? 'text-red-400' : 'text-[var(--muted-foreground)]'}`}>
            {session.confidence > 0 ? `${Math.round(session.confidence * 100)}%` : '—'}
          </p>
        </div>
        <div className="text-center">
          <p className="text-[var(--muted-foreground)]">Duration</p>
          <p className="font-medium text-[var(--card-foreground)]">{session.duration}</p>
        </div>
      </div>

      <div className="hidden items-center gap-4 md:flex">
        <span className="text-sm text-[var(--muted-foreground)]">{session.timestamp}</span>
        <Button 
          variant="ghost" 
          size="sm" 
          className="gap-1 text-[var(--primary)] opacity-0 transition-opacity group-hover:opacity-100"
        >
          <Eye className="h-4 w-4" />
          View Graph
        </Button>
        <ChevronRight className="h-4 w-4 text-[var(--muted-foreground)] opacity-0 transition-opacity group-hover:opacity-100" />
      </div>
    </Link>
  )
}

export default function SessionsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null)

  const filteredSessions = mockSessions.filter((session) => {
    const matchesSearch = 
      session.agentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.summary.toLowerCase().includes(searchQuery.toLowerCase())
    
    const matchesStatus = !selectedStatus || session.status === selectedStatus

    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[var(--card-foreground)]">Reasoning Sessions</h1>
        <p className="text-[var(--muted-foreground)]">
          View and analyze all agent reasoning sessions
        </p>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--muted-foreground)]" />
          <Input
            placeholder="Search sessions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 border-[var(--border)] bg-[var(--muted)] text-[var(--card-foreground)] placeholder:text-[var(--muted-foreground)]"
          />
        </div>

        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            className={`gap-2 border-[var(--border)] ${!selectedStatus ? 'bg-[var(--primary)]/10 text-[var(--primary)] border-[var(--primary)]' : 'text-[var(--muted-foreground)]'}`}
            onClick={() => setSelectedStatus(null)}
          >
            All
          </Button>
          {Object.entries(statusConfig).map(([key, config]) => {
            const Icon = config.icon
            return (
              <Button
                key={key}
                variant="outline"
                size="sm"
                className={`gap-1.5 border-[var(--border)] ${selectedStatus === key ? `${config.bg} ${config.color} border-current` : 'text-[var(--muted-foreground)]'}`}
                onClick={() => setSelectedStatus(key)}
              >
                <Icon className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{config.label}</span>
              </Button>
            )
          })}
          <Button variant="outline" size="sm" className="gap-2 border-[var(--border)] text-[var(--muted-foreground)]">
            <Filter className="h-4 w-4" />
            <span className="hidden sm:inline">More Filters</span>
          </Button>
        </div>
      </div>

      <div className="flex items-center justify-between border-b border-[var(--border)] pb-2 text-sm text-[var(--muted-foreground)]">
        <span>{filteredSessions.length} sessions</span>
        <Button variant="ghost" size="sm" className="gap-1 text-[var(--muted-foreground)]">
          <ArrowUpDown className="h-3.5 w-3.5" />
          Sort by time
        </Button>
      </div>

      <div className="space-y-3">
        {filteredSessions.map((session) => (
          <SessionRow key={session.id} session={session} />
        ))}
      </div>

      {filteredSessions.length === 0 && (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <Search className="h-12 w-12 text-[var(--muted-foreground)]/50" />
          <h3 className="mt-4 text-lg font-medium text-[var(--card-foreground)]">No sessions found</h3>
          <p className="mt-1 text-[var(--muted-foreground)]">
            Try adjusting your search or filter criteria
          </p>
        </div>
      )}
    </div>
  )
}
