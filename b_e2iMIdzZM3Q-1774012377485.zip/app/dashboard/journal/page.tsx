'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'

type EntryType = 'all' | 'belief' | 'inference' | 'decision' | 'constraint'

interface JournalEntry {
  id: string
  timestamp: string
  type: 'belief' | 'inference' | 'decision' | 'constraint'
  sessionId: string
  agentId: string
  content: string
  confidence?: number
  sources?: string[]
  outcome?: 'success' | 'failure' | 'pending'
}

const mockEntries: JournalEntry[] = [
  {
    id: 'entry-001',
    timestamp: '2026-03-20T14:32:18Z',
    type: 'decision',
    sessionId: 'sess_7x9k2m',
    agentId: 'claims-processor',
    content: 'Approved claim #CLM-2847 for $12,450 based on policy coverage verification and damage assessment alignment.',
    confidence: 0.94,
    sources: ['policy_doc_v2.pdf', 'damage_report_2847.json'],
    outcome: 'success',
  },
  {
    id: 'entry-002',
    timestamp: '2026-03-20T14:31:45Z',
    type: 'inference',
    sessionId: 'sess_7x9k2m',
    agentId: 'claims-processor',
    content: 'Inferred water damage likely caused by pipe burst based on photo analysis and weather data correlation.',
    confidence: 0.89,
    sources: ['weather_api', 'image_analysis_model'],
  },
  {
    id: 'entry-003',
    timestamp: '2026-03-20T14:30:22Z',
    type: 'belief',
    sessionId: 'sess_7x9k2m',
    agentId: 'claims-processor',
    content: 'Policy holder has valid coverage for water damage under Section 4.2 of their home insurance policy.',
    confidence: 1.0,
    sources: ['policy_doc_v2.pdf'],
  },
  {
    id: 'entry-004',
    timestamp: '2026-03-20T14:28:55Z',
    type: 'constraint',
    sessionId: 'sess_7x9k2m',
    agentId: 'claims-processor',
    content: 'Maximum payout for water damage claims is capped at $50,000 per incident as per policy terms.',
    sources: ['policy_doc_v2.pdf'],
  },
  {
    id: 'entry-005',
    timestamp: '2026-03-20T14:15:33Z',
    type: 'decision',
    sessionId: 'sess_3m8n1p',
    agentId: 'legal-reviewer',
    content: 'Flagged contract clause 7.3 for human review due to potential conflict with local regulations.',
    confidence: 0.76,
    sources: ['contract_draft.docx', 'regulation_db'],
    outcome: 'pending',
  },
  {
    id: 'entry-006',
    timestamp: '2026-03-20T13:58:12Z',
    type: 'inference',
    sessionId: 'sess_3m8n1p',
    agentId: 'legal-reviewer',
    content: 'Identified non-compete clause may be unenforceable in California based on state law precedents.',
    confidence: 0.92,
    sources: ['case_law_db', 'ca_business_code'],
  },
  {
    id: 'entry-007',
    timestamp: '2026-03-20T13:45:00Z',
    type: 'belief',
    sessionId: 'sess_9k2j4w',
    agentId: 'diagnosis-assistant',
    content: 'Patient symptoms consistent with Type 2 Diabetes based on HbA1c levels and reported symptoms.',
    confidence: 0.87,
    sources: ['lab_results.json', 'patient_history'],
  },
  {
    id: 'entry-008',
    timestamp: '2026-03-20T13:42:18Z',
    type: 'constraint',
    sessionId: 'sess_9k2j4w',
    agentId: 'diagnosis-assistant',
    content: 'HIPAA compliance required: patient data must not be logged or transmitted to third-party services.',
    sources: ['hipaa_guidelines'],
  },
]

const typeColors = {
  belief: { bg: 'bg-blue-500/10', border: 'border-blue-500/30', text: 'text-blue-400', dot: 'bg-blue-400' },
  inference: { bg: 'bg-purple-500/10', border: 'border-purple-500/30', text: 'text-purple-400', dot: 'bg-purple-400' },
  decision: { bg: 'bg-accent/10', border: 'border-accent/30', text: 'text-accent', dot: 'bg-accent' },
  constraint: { bg: 'bg-amber-500/10', border: 'border-amber-500/30', text: 'text-amber-400', dot: 'bg-amber-400' },
}

export default function JournalPage() {
  const [filter, setFilter] = useState<EntryType>('all')
  const [search, setSearch] = useState('')
  const [expandedEntry, setExpandedEntry] = useState<string | null>(null)

  const filteredEntries = mockEntries.filter((entry) => {
    const matchesFilter = filter === 'all' || entry.type === filter
    const matchesSearch = search === '' || 
      entry.content.toLowerCase().includes(search.toLowerCase()) ||
      entry.agentId.toLowerCase().includes(search.toLowerCase()) ||
      entry.sessionId.toLowerCase().includes(search.toLowerCase())
    return matchesFilter && matchesSearch
  })

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  }

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reasoning Journal</h1>
          <p className="text-muted-foreground">Complete audit trail of all AI reasoning events.</p>
        </div>
        <Button variant="outline" className="gap-2">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Export Journal
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <Input
            placeholder="Search entries, agents, or sessions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-card/50 border-border/50"
          />
        </div>
        <div className="flex gap-2">
          {(['all', 'belief', 'inference', 'decision', 'constraint'] as EntryType[]).map((type) => (
            <Button
              key={type}
              variant={filter === type ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(type)}
              className={cn(
                'capitalize',
                filter === type && 'bg-primary text-primary-foreground'
              )}
            >
              {type}
            </Button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Total Entries', value: mockEntries.length, color: 'text-foreground' },
          { label: 'Decisions', value: mockEntries.filter(e => e.type === 'decision').length, color: 'text-accent' },
          { label: 'Avg Confidence', value: '89%', color: 'text-primary' },
          { label: 'Active Sessions', value: '3', color: 'text-purple-400' },
        ].map((stat) => (
          <div key={stat.label} className="p-4 rounded-xl bg-card/50 border border-border/50">
            <p className="text-sm text-muted-foreground">{stat.label}</p>
            <p className={cn('text-2xl font-bold', stat.color)}>{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Journal Entries */}
      <div className="space-y-3">
        {filteredEntries.map((entry) => {
          const colors = typeColors[entry.type]
          const isExpanded = expandedEntry === entry.id

          return (
            <div
              key={entry.id}
              className={cn(
                'rounded-xl border bg-card/50 backdrop-blur-sm overflow-hidden transition-all duration-200 cursor-pointer hover:border-primary/30',
                colors.border,
                isExpanded && 'ring-1 ring-primary/30'
              )}
              onClick={() => setExpandedEntry(isExpanded ? null : entry.id)}
            >
              <div className="p-4">
                <div className="flex items-start gap-4">
                  {/* Type indicator */}
                  <div className={cn('mt-1 w-2 h-2 rounded-full shrink-0', colors.dot)} />

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={cn('text-xs font-medium uppercase tracking-wider', colors.text)}>
                        {entry.type}
                      </span>
                      {entry.confidence !== undefined && (
                        <span className="text-xs text-muted-foreground">
                          {Math.round(entry.confidence * 100)}% confidence
                        </span>
                      )}
                      {entry.outcome && (
                        <span className={cn(
                          'text-xs px-1.5 py-0.5 rounded',
                          entry.outcome === 'success' && 'bg-accent/20 text-accent',
                          entry.outcome === 'failure' && 'bg-red-500/20 text-red-400',
                          entry.outcome === 'pending' && 'bg-amber-500/20 text-amber-400'
                        )}>
                          {entry.outcome}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-foreground leading-relaxed">{entry.content}</p>
                    <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                      <span className="font-mono">{entry.agentId}</span>
                      <span>{entry.sessionId}</span>
                    </div>
                  </div>

                  {/* Timestamp */}
                  <div className="text-right shrink-0">
                    <p className="text-xs font-medium">{formatTime(entry.timestamp)}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(entry.timestamp)}</p>
                  </div>
                </div>

                {/* Expanded details */}
                {isExpanded && entry.sources && (
                  <div className="mt-4 pt-4 border-t border-border/50">
                    <p className="text-xs font-medium text-muted-foreground mb-2">Sources</p>
                    <div className="flex flex-wrap gap-2">
                      {entry.sources.map((source) => (
                        <span
                          key={source}
                          className="text-xs px-2 py-1 rounded-md bg-secondary/50 text-muted-foreground font-mono"
                        >
                          {source}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {filteredEntries.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No entries match your filters.</p>
        </div>
      )}
    </div>
  )
}
