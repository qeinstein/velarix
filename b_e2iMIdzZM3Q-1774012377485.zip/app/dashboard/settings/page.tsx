"use client"

import { useState } from "react"
import { 
  Key, 
  Copy, 
  Eye, 
  EyeOff, 
  Plus, 
  Trash2, 
  Shield, 
  Bell, 
  User, 
  Building2,
  Check,
  AlertTriangle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ApiKey {
  id: string
  name: string
  key: string
  created: string
  lastUsed: string
  permissions: string[]
}

const mockApiKeys: ApiKey[] = [
  {
    id: "1",
    name: "Production API Key",
    key: "vlx_prod_sk_7f8a9b2c3d4e5f6g7h8i9j0k",
    created: "2024-01-15",
    lastUsed: "2 minutes ago",
    permissions: ["read", "write", "audit"]
  },
  {
    id: "2", 
    name: "Development Key",
    key: "vlx_dev_sk_1a2b3c4d5e6f7g8h9i0j1k2l",
    created: "2024-02-20",
    lastUsed: "1 hour ago",
    permissions: ["read", "write"]
  },
  {
    id: "3",
    name: "Read-Only Audit Key",
    key: "vlx_audit_sk_9z8y7x6w5v4u3t2s1r0q9p8o",
    created: "2024-03-01",
    lastUsed: "3 days ago",
    permissions: ["read", "audit"]
  }
]

function ApiKeyRow({ apiKey }: { apiKey: ApiKey }) {
  const [isVisible, setIsVisible] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    navigator.clipboard.writeText(apiKey.key)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const maskedKey = apiKey.key.substring(0, 12) + "••••••••••••••••"

  return (
    <div className="group relative rounded-lg border border-[var(--border)] bg-[var(--card)]/50 p-4 transition-all hover:border-[var(--primary)]/30 hover:bg-[var(--card)]">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 space-y-2">
          <div className="flex items-center gap-2">
            <Key className="h-4 w-4 text-[var(--primary)]" />
            <span className="font-medium text-[var(--card-foreground)]">{apiKey.name}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <code className="rounded bg-[var(--muted)] px-2 py-1 font-mono text-sm text-[var(--muted-foreground)]">
              {isVisible ? apiKey.key : maskedKey}
            </code>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0 text-[var(--muted-foreground)] hover:text-[var(--card-foreground)]"
              onClick={() => setIsVisible(!isVisible)}
            >
              {isVisible ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0 text-[var(--muted-foreground)] hover:text-[var(--card-foreground)]"
              onClick={handleCopy}
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
            </Button>
          </div>

          <div className="flex items-center gap-4 text-xs text-[var(--muted-foreground)]">
            <span>Created: {apiKey.created}</span>
            <span>Last used: {apiKey.lastUsed}</span>
          </div>

          <div className="flex items-center gap-1.5">
            {apiKey.permissions.map((perm) => (
              <Badge 
                key={perm} 
                variant="secondary"
                className="bg-[var(--primary)]/10 text-[var(--primary)] text-xs"
              >
                {perm}
              </Badge>
            ))}
          </div>
        </div>

        <Button
          variant="ghost"
          size="sm"
          className="text-[var(--muted-foreground)] opacity-0 transition-opacity hover:text-red-400 group-hover:opacity-100"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

function ApiKeysTab() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-[var(--card-foreground)]">API Keys</h3>
          <p className="text-sm text-[var(--muted-foreground)]">
            Manage your API keys for accessing Velarix services
          </p>
        </div>
        <Button className="gap-2 bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)]/90">
          <Plus className="h-4 w-4" />
          Create New Key
        </Button>
      </div>

      <Card className="border-amber-500/20 bg-amber-500/5">
        <CardContent className="flex items-center gap-3 p-4">
          <AlertTriangle className="h-5 w-5 text-amber-400" />
          <p className="text-sm text-amber-200">
            Keep your API keys secure. Never share them in public repositories or client-side code.
          </p>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {mockApiKeys.map((key) => (
          <ApiKeyRow key={key.id} apiKey={key} />
        ))}
      </div>
    </div>
  )
}

function SecurityTab() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-[var(--card-foreground)]">Security Settings</h3>
        <p className="text-sm text-[var(--muted-foreground)]">
          Configure security policies for your organization
        </p>
      </div>

      <div className="space-y-4">
        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="font-medium text-[var(--card-foreground)]">Two-Factor Authentication</p>
                <p className="text-sm text-[var(--muted-foreground)]">
                  Require 2FA for all team members
                </p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="font-medium text-[var(--card-foreground)]">IP Allowlisting</p>
                <p className="text-sm text-[var(--muted-foreground)]">
                  Restrict API access to specific IP ranges
                </p>
              </div>
              <Switch />
            </div>
          </CardContent>
        </Card>

        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="font-medium text-[var(--card-foreground)]">Audit Log Retention</p>
                <p className="text-sm text-[var(--muted-foreground)]">
                  How long to retain reasoning audit logs
                </p>
              </div>
              <select className="rounded-md border border-[var(--border)] bg-[var(--muted)] px-3 py-1.5 text-sm text-[var(--card-foreground)]">
                <option>30 days</option>
                <option>90 days</option>
                <option>1 year</option>
                <option>Forever</option>
              </select>
            </div>
          </CardContent>
        </Card>

        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="font-medium text-[var(--card-foreground)]">Session Timeout</p>
                <p className="text-sm text-[var(--muted-foreground)]">
                  Automatic logout after inactivity
                </p>
              </div>
              <select className="rounded-md border border-[var(--border)] bg-[var(--muted)] px-3 py-1.5 text-sm text-[var(--card-foreground)]">
                <option>15 minutes</option>
                <option>30 minutes</option>
                <option>1 hour</option>
                <option>4 hours</option>
              </select>
            </div>
          </CardContent>
        </Card>

        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="font-medium text-[var(--card-foreground)]">SSO/SAML Integration</p>
                <p className="text-sm text-[var(--muted-foreground)]">
                  Connect enterprise identity provider
                </p>
              </div>
              <Button variant="outline" size="sm" className="border-[var(--primary)] text-[var(--primary)]">
                Configure
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function NotificationsTab() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-[var(--card-foreground)]">Notification Preferences</h3>
        <p className="text-sm text-[var(--muted-foreground)]">
          Configure how you want to be notified about agent activity
        </p>
      </div>

      <div className="space-y-4">
        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-[var(--muted-foreground)]">
              REASONING ALERTS
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[var(--card-foreground)]">Low confidence decisions</span>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[var(--card-foreground)]">Constraint violations</span>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[var(--card-foreground)]">Human override required</span>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-[var(--muted-foreground)]">
              SYSTEM NOTIFICATIONS
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[var(--card-foreground)]">API usage limits</span>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[var(--card-foreground)]">Weekly digest</span>
              <Switch />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[var(--card-foreground)]">Product updates</span>
              <Switch />
            </div>
          </CardContent>
        </Card>

        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-[var(--muted-foreground)]">
              DELIVERY CHANNELS
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[var(--card-foreground)]">Email notifications</span>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[var(--card-foreground)]">Slack integration</span>
              <Button variant="outline" size="sm" className="border-[var(--primary)] text-[var(--primary)]">
                Connect
              </Button>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[var(--card-foreground)]">Webhook alerts</span>
              <Button variant="outline" size="sm" className="border-[var(--primary)] text-[var(--primary)]">
                Configure
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function ProfileTab() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-[var(--card-foreground)]">Profile Settings</h3>
        <p className="text-sm text-[var(--muted-foreground)]">
          Manage your account information
        </p>
      </div>

      <Card className="border-[var(--border)] bg-[var(--card)]/50">
        <CardContent className="p-6">
          <div className="flex items-center gap-6">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-[var(--primary)] to-cyan-500">
              <span className="text-2xl font-bold text-[var(--primary-foreground)]">JD</span>
            </div>
            <div>
              <h4 className="text-xl font-semibold text-[var(--card-foreground)]">Jane Doe</h4>
              <p className="text-[var(--muted-foreground)]">jane@acmecorp.com</p>
              <Badge className="mt-2 bg-[var(--primary)]/10 text-[var(--primary)]">Admin</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-[var(--card-foreground)]">Full Name</label>
          <Input 
            defaultValue="Jane Doe" 
            className="border-[var(--border)] bg-[var(--muted)] text-[var(--card-foreground)]"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-[var(--card-foreground)]">Email</label>
          <Input 
            defaultValue="jane@acmecorp.com" 
            className="border-[var(--border)] bg-[var(--muted)] text-[var(--card-foreground)]"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-[var(--card-foreground)]">Role</label>
          <Input 
            defaultValue="Platform Administrator" 
            className="border-[var(--border)] bg-[var(--muted)] text-[var(--card-foreground)]"
          />
        </div>
      </div>

      <div className="flex gap-3">
        <Button className="bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)]/90">
          Save Changes
        </Button>
        <Button variant="outline" className="border-[var(--border)] text-[var(--muted-foreground)]">
          Cancel
        </Button>
      </div>
    </div>
  )
}

function OrganizationTab() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-[var(--card-foreground)]">Organization Settings</h3>
        <p className="text-sm text-[var(--muted-foreground)]">
          Manage your organization and team members
        </p>
      </div>

      <Card className="border-[var(--border)] bg-[var(--card)]/50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-gradient-to-br from-[var(--primary)] to-cyan-500">
              <Building2 className="h-7 w-7 text-[var(--primary-foreground)]" />
            </div>
            <div>
              <h4 className="text-lg font-semibold text-[var(--card-foreground)]">Acme Corp</h4>
              <p className="text-sm text-[var(--muted-foreground)]">Enterprise Plan</p>
            </div>
            <Badge className="ml-auto bg-emerald-500/10 text-emerald-400">Active</Badge>
          </div>
        </CardContent>
      </Card>

      <Card className="border-[var(--border)] bg-[var(--card)]/50">
        <CardHeader>
          <CardTitle className="text-[var(--card-foreground)]">Usage This Month</CardTitle>
          <CardDescription className="text-[var(--muted-foreground)]">
            Billing period: Mar 1 - Mar 31, 2024
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="space-y-1">
              <p className="text-sm text-[var(--muted-foreground)]">Reasoning Sessions</p>
              <p className="text-2xl font-bold text-[var(--card-foreground)]">847,293</p>
              <p className="text-xs text-[var(--muted-foreground)]">of 1,000,000</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-[var(--muted-foreground)]">Active Agents</p>
              <p className="text-2xl font-bold text-[var(--card-foreground)]">23</p>
              <p className="text-xs text-[var(--muted-foreground)]">of 50</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-[var(--muted-foreground)]">Team Members</p>
              <p className="text-2xl font-bold text-[var(--card-foreground)]">12</p>
              <p className="text-xs text-[var(--muted-foreground)]">of unlimited</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-[var(--border)] bg-[var(--card)]/50">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-[var(--card-foreground)]">Team Members</CardTitle>
            <CardDescription className="text-[var(--muted-foreground)]">
              Manage who has access to Velarix
            </CardDescription>
          </div>
          <Button size="sm" className="gap-2 bg-[var(--primary)] text-[var(--primary-foreground)]">
            <Plus className="h-4 w-4" />
            Invite
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { name: "Jane Doe", email: "jane@acmecorp.com", role: "Admin" },
              { name: "John Smith", email: "john@acmecorp.com", role: "Developer" },
              { name: "Sarah Wilson", email: "sarah@acmecorp.com", role: "Auditor" },
            ].map((member) => (
              <div key={member.email} className="flex items-center justify-between rounded-lg border border-[var(--border)] bg-[var(--muted)]/50 p-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[var(--primary)]/20">
                    <span className="text-sm font-medium text-[var(--primary)]">
                      {member.name.split(" ").map(n => n[0]).join("")}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-[var(--card-foreground)]">{member.name}</p>
                    <p className="text-sm text-[var(--muted-foreground)]">{member.email}</p>
                  </div>
                </div>
                <Badge variant="secondary" className="bg-[var(--muted)] text-[var(--muted-foreground)]">
                  {member.role}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[var(--card-foreground)]">Settings</h1>
        <p className="text-[var(--muted-foreground)]">
          Manage your account, security, and organization settings
        </p>
      </div>

      <Tabs defaultValue="api-keys" className="space-y-6">
        <TabsList className="border-b border-[var(--border)] bg-transparent p-0">
          <TabsTrigger 
            value="api-keys"
            className="gap-2 rounded-none border-b-2 border-transparent px-4 pb-3 pt-2 text-[var(--muted-foreground)] data-[state=active]:border-[var(--primary)] data-[state=active]:text-[var(--primary)]"
          >
            <Key className="h-4 w-4" />
            API Keys
          </TabsTrigger>
          <TabsTrigger 
            value="security"
            className="gap-2 rounded-none border-b-2 border-transparent px-4 pb-3 pt-2 text-[var(--muted-foreground)] data-[state=active]:border-[var(--primary)] data-[state=active]:text-[var(--primary)]"
          >
            <Shield className="h-4 w-4" />
            Security
          </TabsTrigger>
          <TabsTrigger 
            value="notifications"
            className="gap-2 rounded-none border-b-2 border-transparent px-4 pb-3 pt-2 text-[var(--muted-foreground)] data-[state=active]:border-[var(--primary)] data-[state=active]:text-[var(--primary)]"
          >
            <Bell className="h-4 w-4" />
            Notifications
          </TabsTrigger>
          <TabsTrigger 
            value="profile"
            className="gap-2 rounded-none border-b-2 border-transparent px-4 pb-3 pt-2 text-[var(--muted-foreground)] data-[state=active]:border-[var(--primary)] data-[state=active]:text-[var(--primary)]"
          >
            <User className="h-4 w-4" />
            Profile
          </TabsTrigger>
          <TabsTrigger 
            value="organization"
            className="gap-2 rounded-none border-b-2 border-transparent px-4 pb-3 pt-2 text-[var(--muted-foreground)] data-[state=active]:border-[var(--primary)] data-[state=active]:text-[var(--primary)]"
          >
            <Building2 className="h-4 w-4" />
            Organization
          </TabsTrigger>
        </TabsList>

        <TabsContent value="api-keys">
          <ApiKeysTab />
        </TabsContent>

        <TabsContent value="security">
          <SecurityTab />
        </TabsContent>

        <TabsContent value="notifications">
          <NotificationsTab />
        </TabsContent>

        <TabsContent value="profile">
          <ProfileTab />
        </TabsContent>

        <TabsContent value="organization">
          <OrganizationTab />
        </TabsContent>
      </Tabs>
    </div>
  )
}
