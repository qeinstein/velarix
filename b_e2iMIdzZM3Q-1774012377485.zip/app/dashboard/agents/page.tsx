"use client"

import { useState } from "react"
import { 
  Bot, 
  Plus, 
  MoreVertical, 
  Activity, 
  AlertTriangle,
  CheckCircle2,
  Pause,
  Play,
  Settings,
  Trash2,
  Copy,
  ExternalLink
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface Agent {
  id: string
  name: string
  description: string
  status: "active" | "paused" | "error"
  sessionsToday: number
  successRate: number
  avgConfidence: number
  lastActive: string
  constraints: string[]
}

const mockAgents: Agent[] = [
  {
    id: "agent_claims",
    name: "Claims Processor",
    description: "Handles insurance claims evaluation and approval workflows",
    status: "active",
    sessionsToday: 1247,
    successRate: 0.94,
    avgConfidence: 0.89,
    lastActive: "2 minutes ago",
    constraints: ["max_payout: $50,000", "require_verification: true", "auto_approve_threshold: 0.95"]
  },
  {
    id: "agent_underwriting",
    name: "Underwriting Agent",
    description: "Evaluates risk profiles and determines policy terms",
    status: "active",
    sessionsToday: 892,
    successRate: 0.88,
    avgConfidence: 0.82,
    lastActive: "5 minutes ago",
    constraints: ["risk_threshold: moderate", "manual_review_required: high_value", "credit_check: required"]
  },
  {
    id: "agent_fraud",
    name: "Fraud Detection",
    description: "Real-time fraud pattern detection and prevention",
    status: "active",
    sessionsToday: 3421,
    successRate: 0.97,
    avgConfidence: 0.91,
    lastActive: "Just now",
    constraints: ["block_threshold: 0.85", "escalate_threshold: 0.6", "max_false_positive: 2%"]
  },
  {
    id: "agent_support",
    name: "Support Agent",
    description: "Customer inquiry handling and resolution",
    status: "paused",
    sessionsToday: 0,
    successRate: 0.91,
    avgConfidence: 0.87,
    lastActive: "2 hours ago",
    constraints: ["escalate_after: 3_attempts", "sentiment_threshold: negative", "response_time: 30s"]
  },
  {
    id: "agent_compliance",
    name: "Compliance Agent",
    description: "Regulatory compliance monitoring and reporting",
    status: "active",
    sessionsToday: 156,
    successRate: 0.99,
    avgConfidence: 0.95,
    lastActive: "15 minutes ago",
    constraints: ["audit_frequency: daily", "report_format: SOC2", "retention_period: 7_years"]
  },
  {
    id: "agent_pricing",
    name: "Dynamic Pricing",
    description: "Real-time premium calculation and optimization",
    status: "error",
    sessionsToday: 0,
    successRate: 0.0,
    avgConfidence: 0.0,
    lastActive: "1 hour ago",
    constraints: ["max_adjustment: 15%", "market_factor: enabled", "competitor_aware: true"]
  },
]

const statusConfig = {
  active: { 
    color: "text-emerald-400", 
    bg: "bg-emerald-400/10",
    border: "border-emerald-400/30",
    label: "Active",
    dot: "bg-emerald-400"
  },
  paused: { 
    color: "text-amber-400", 
    bg: "bg-amber-400/10",
    border: "border-amber-400/30",
    label: "Paused",
    dot: "bg-amber-400"
  },
  error: { 
    color: "text-red-400", 
    bg: "bg-red-400/10",
    border: "border-red-400/30",
    label: "Error",
    dot: "bg-red-400"
  },
}

function AgentCard({ agent }: { agent: Agent }) {
  const status = statusConfig[agent.status]

  return (
    <Card className={`border-[var(--border)] bg-[var(--card)]/50 transition-all hover:border-[var(--primary)]/30 hover:bg-[var(--card)]`}>
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
        <div className="flex items-center gap-3">
          <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${status.bg} ${status.border} border`}>
            <Bot className={`h-5 w-5 ${status.color}`} />
          </div>
          <div>
            <CardTitle className="text-base font-semibold text-[var(--card-foreground)]">
              {agent.name}
            </CardTitle>
            <p className="text-xs text-[var(--muted-foreground)]">{agent.id}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <span className={`h-2 w-2 rounded-full ${status.dot} ${agent.status === 'active' ? 'animate-pulse' : ''}`} />
            <span className={`text-xs font-medium ${status.color}`}>{status.label}</span>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-[var(--muted-foreground)]">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="border-[var(--border)] bg-[var(--card)]">
              <DropdownMenuItem className="gap-2 text-[var(--card-foreground)]">
                <Settings className="h-4 w-4" />
                Configure
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2 text-[var(--card-foreground)]">
                <Activity className="h-4 w-4" />
                View Sessions
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2 text-[var(--card-foreground)]">
                <Copy className="h-4 w-4" />
                Duplicate
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-[var(--border)]" />
              {agent.status === "active" ? (
                <DropdownMenuItem className="gap-2 text-amber-400">
                  <Pause className="h-4 w-4" />
                  Pause Agent
                </DropdownMenuItem>
              ) : agent.status === "paused" ? (
                <DropdownMenuItem className="gap-2 text-emerald-400">
                  <Play className="h-4 w-4" />
                  Resume Agent
                </DropdownMenuItem>
              ) : (
                <DropdownMenuItem className="gap-2 text-emerald-400">
                  <Play className="h-4 w-4" />
                  Restart Agent
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator className="bg-[var(--border)]" />
              <DropdownMenuItem className="gap-2 text-red-400">
                <Trash2 className="h-4 w-4" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-[var(--muted-foreground)]">{agent.description}</p>

        <div className="grid grid-cols-3 gap-4">
          <div>
            <p className="text-xs text-[var(--muted-foreground)]">Sessions Today</p>
            <p className="text-lg font-semibold text-[var(--card-foreground)]">
              {agent.sessionsToday.toLocaleString()}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--muted-foreground)]">Success Rate</p>
            <p className={`text-lg font-semibold ${agent.successRate >= 0.9 ? 'text-emerald-400' : agent.successRate >= 0.8 ? 'text-amber-400' : 'text-red-400'}`}>
              {agent.successRate > 0 ? `${Math.round(agent.successRate * 100)}%` : '—'}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--muted-foreground)]">Avg Confidence</p>
            <p className={`text-lg font-semibold ${agent.avgConfidence >= 0.85 ? 'text-emerald-400' : agent.avgConfidence >= 0.7 ? 'text-amber-400' : agent.avgConfidence > 0 ? 'text-red-400' : 'text-[var(--muted-foreground)]'}`}>
              {agent.avgConfidence > 0 ? `${Math.round(agent.avgConfidence * 100)}%` : '—'}
            </p>
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-medium text-[var(--muted-foreground)]">CONSTRAINTS</p>
          <div className="flex flex-wrap gap-1.5">
            {agent.constraints.slice(0, 3).map((constraint, index) => (
              <Badge 
                key={index}
                variant="secondary" 
                className="bg-[var(--muted)] text-[var(--muted-foreground)] text-xs font-mono"
              >
                {constraint}
              </Badge>
            ))}
            {agent.constraints.length > 3 && (
              <Badge 
                variant="secondary" 
                className="bg-[var(--primary)]/10 text-[var(--primary)] text-xs"
              >
                +{agent.constraints.length - 3} more
              </Badge>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-[var(--border)]">
          <span className="text-xs text-[var(--muted-foreground)]">
            Last active: {agent.lastActive}
          </span>
          <Button variant="ghost" size="sm" className="gap-1 text-xs text-[var(--primary)]">
            <ExternalLink className="h-3 w-3" />
            Details
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export default function AgentsPage() {
  const activeCount = mockAgents.filter(a => a.status === "active").length
  const errorCount = mockAgents.filter(a => a.status === "error").length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--card-foreground)]">Agents</h1>
          <p className="text-[var(--muted-foreground)]">
            Manage and monitor your AI agents
          </p>
        </div>
        <Button className="gap-2 bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)]/90">
          <Plus className="h-4 w-4" />
          Register Agent
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-[var(--primary)]/10">
              <Bot className="h-6 w-6 text-[var(--primary)]" />
            </div>
            <div>
              <p className="text-sm text-[var(--muted-foreground)]">Total Agents</p>
              <p className="text-2xl font-bold text-[var(--card-foreground)]">{mockAgents.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-emerald-400/10">
              <CheckCircle2 className="h-6 w-6 text-emerald-400" />
            </div>
            <div>
              <p className="text-sm text-[var(--muted-foreground)]">Active</p>
              <p className="text-2xl font-bold text-emerald-400">{activeCount}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-[var(--border)] bg-[var(--card)]/50">
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-red-400/10">
              <AlertTriangle className="h-6 w-6 text-red-400" />
            </div>
            <div>
              <p className="text-sm text-[var(--muted-foreground)]">Errors</p>
              <p className="text-2xl font-bold text-red-400">{errorCount}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {mockAgents.map((agent) => (
          <AgentCard key={agent.id} agent={agent} />
        ))}
      </div>
    </div>
  )
}
