'use client'

import Link from 'next/link'
import { Navigation } from '@/components/landing/navigation'
import { Footer } from '@/components/landing/footer'
import { cn } from '@/lib/utils'

const releases = [
  {
    version: '0.9.0',
    date: 'March 18, 2026',
    title: 'Neural Graph Playback',
    type: 'feature',
    changes: [
      'Time-travel debugging for reasoning chains',
      'Visual diff between decision points',
      'Export reasoning graphs as SVG/PNG',
      'Keyboard shortcuts for navigation',
    ],
  },
  {
    version: '0.8.2',
    date: 'March 10, 2026',
    title: 'Performance Improvements',
    type: 'improvement',
    changes: [
      'Reduced latency by 40% for constraint evaluation',
      'Optimized database queries for large sessions',
      'Improved WebSocket connection stability',
      'Memory usage optimization for long-running agents',
    ],
  },
  {
    version: '0.8.1',
    date: 'March 5, 2026',
    title: 'Bug Fixes',
    type: 'fix',
    changes: [
      'Fixed issue with session reconnection after network interruption',
      'Resolved constraint validation edge cases',
      'Fixed timezone handling in audit logs',
      'Corrected API rate limit calculation',
    ],
  },
  {
    version: '0.8.0',
    date: 'February 28, 2026',
    title: 'Custom Constraints Engine',
    type: 'feature',
    changes: [
      'Define custom domain-specific constraints',
      'Constraint templates for healthcare, legal, finance',
      'Real-time constraint violation alerts',
      'Constraint inheritance and composition',
    ],
  },
  {
    version: '0.7.5',
    date: 'February 20, 2026',
    title: 'API Enhancements',
    type: 'improvement',
    changes: [
      'New streaming API for real-time updates',
      'Batch operations for bulk data retrieval',
      'Improved error messages and codes',
      'OpenAPI 3.1 specification update',
    ],
  },
  {
    version: '0.7.0',
    date: 'February 10, 2026',
    title: 'Team Collaboration',
    type: 'feature',
    changes: [
      'Multi-user workspaces',
      'Role-based access control',
      'Shared agent configurations',
      'Team activity feed',
      'Comment threads on reasoning chains',
    ],
  },
]

const typeStyles = {
  feature: { label: 'New Feature', color: 'bg-accent/20 text-accent' },
  improvement: { label: 'Improvement', color: 'bg-blue-500/20 text-blue-400' },
  fix: { label: 'Bug Fix', color: 'bg-amber-500/20 text-amber-400' },
}

export default function ChangelogPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">Changelog</h1>
            <p className="text-lg text-muted-foreground">
              New features, improvements, and fixes. Subscribe to our{' '}
              <Link href="/blog" className="text-primary hover:underline">
                blog
              </Link>{' '}
              for detailed release notes.
            </p>
          </div>

          {/* Timeline */}
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 top-0 bottom-0 w-px bg-border/50" />

            <div className="space-y-12">
              {releases.map((release) => {
                const style = typeStyles[release.type as keyof typeof typeStyles]
                return (
                  <div key={release.version} className="relative pl-8">
                    {/* Timeline dot */}
                    <div className="absolute left-0 top-0 w-2 h-2 rounded-full bg-primary -translate-x-[3px]" />

                    {/* Content */}
                    <div className="rounded-xl border border-border/50 bg-card/50 p-6">
                      <div className="flex flex-wrap items-center gap-3 mb-3">
                        <span className="font-mono text-sm text-primary">v{release.version}</span>
                        <span className="text-sm text-muted-foreground">{release.date}</span>
                        <span className={cn('text-xs px-2 py-0.5 rounded-full', style.color)}>
                          {style.label}
                        </span>
                      </div>
                      <h3 className="text-xl font-semibold mb-4">{release.title}</h3>
                      <ul className="space-y-2">
                        {release.changes.map((change, idx) => (
                          <li key={idx} className="flex items-start gap-3 text-sm text-muted-foreground">
                            <svg className="w-4 h-4 text-accent shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                            {change}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Load More */}
          <div className="mt-12 text-center">
            <button className="text-sm text-primary hover:underline">
              View older releases
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
