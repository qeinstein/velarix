'use client'

import { useRef, useEffect, useState } from 'react'
import { cn } from '@/lib/utils'

const codeLines = [
  { content: '// Before: Direct agent calls', type: 'comment' },
  { content: 'const response = await agent.decide(input)', type: 'code', highlight: false },
  { content: '', type: 'empty' },
  { content: '// After: Reasoning-tracked decisions', type: 'comment' },
  { content: 'import { velarix } from "@velarix/sdk"', type: 'import', highlight: true },
  { content: 'const response = await velarix.decide(input)', type: 'code', highlight: true },
]

export function CodeSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const [isVisible, setIsVisible] = useState(false)
  const [activeLineIndex, setActiveLineIndex] = useState(-1)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          // Animate lines appearing one by one
          codeLines.forEach((_, index) => {
            setTimeout(() => setActiveLineIndex(index), index * 150 + 500)
          })
        }
      },
      { threshold: 0.3 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="relative py-32 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div
          className={cn(
            'text-center mb-12 transition-all duration-700',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
            <span className="text-balance">Four lines of code</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Drop in Velarix with a single import swap. Your agent calls stay the same, but now every decision is tracked, validated, and auditable.
          </p>
        </div>

        {/* Code Block */}
        <div
          className={cn(
            'relative rounded-2xl border border-border/50 bg-card/80 backdrop-blur-xl overflow-hidden transition-all duration-700 delay-200',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-secondary/30">
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-destructive/50" />
                <div className="w-3 h-3 rounded-full bg-chart-3/50" />
                <div className="w-3 h-3 rounded-full bg-accent/50" />
              </div>
              <span className="text-xs text-muted-foreground ml-3 font-mono">agent.ts</span>
            </div>
            <button
              className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"
              onClick={() => navigator.clipboard.writeText(codeLines.map(l => l.content).join('\n'))}
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              Copy
            </button>
          </div>

          {/* Code Content */}
          <div className="p-6 font-mono text-sm overflow-x-auto">
            {codeLines.map((line, index) => (
              <div
                key={index}
                className={cn(
                  'flex items-center transition-all duration-500',
                  index <= activeLineIndex ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4',
                  line.highlight && 'bg-primary/5 -mx-6 px-6 py-0.5'
                )}
                style={{ transitionDelay: `${index * 50}ms` }}
              >
                {/* Line number */}
                <span className="w-8 text-muted-foreground/50 select-none text-right mr-6">
                  {line.type !== 'empty' ? index + 1 : ''}
                </span>
                
                {/* Code content */}
                <span className={cn(
                  line.type === 'comment' && 'text-muted-foreground',
                  line.type === 'import' && 'text-primary',
                  line.type === 'code' && !line.highlight && 'text-muted-foreground',
                  line.type === 'code' && line.highlight && 'text-foreground'
                )}>
                  {line.type === 'import' ? (
                    <>
                      <span className="text-chart-4">import</span>
                      <span className="text-foreground">{' { '}</span>
                      <span className="text-primary">velarix</span>
                      <span className="text-foreground">{' } '}</span>
                      <span className="text-chart-4">from</span>
                      <span className="text-accent">{' "@velarix/sdk"'}</span>
                    </>
                  ) : line.type === 'code' ? (
                    <>
                      <span className="text-chart-4">const</span>
                      <span className="text-foreground">{' response = '}</span>
                      <span className="text-chart-4">await</span>
                      <span className={line.highlight ? 'text-primary' : 'text-muted-foreground'}>
                        {line.highlight ? ' velarix' : ' agent'}
                      </span>
                      <span className="text-foreground">.decide</span>
                      <span className="text-muted-foreground">(</span>
                      <span className="text-foreground">input</span>
                      <span className="text-muted-foreground">)</span>
                    </>
                  ) : (
                    line.content
                  )}
                </span>

                {/* Highlight glow for new lines */}
                {line.highlight && index <= activeLineIndex && (
                  <div className="absolute left-0 w-1 h-6 bg-primary animate-pulse" />
                )}
              </div>
            ))}
          </div>

          {/* Ambient glow */}
          <div className="absolute -inset-1 bg-gradient-to-r from-primary/10 via-transparent to-accent/10 rounded-2xl blur-xl opacity-50 -z-10" />
        </div>
      </div>
    </section>
  )
}
