'use client'

import { useEffect, useState, useRef } from 'react'
import { cn } from '@/lib/utils'

interface ExplodedViewProps {
  isVisible: boolean
}

export function ExplodedView({ isVisible }: ExplodedViewProps) {
  const [scrollProgress, setScrollProgress] = useState(0)
  const [isHovered, setIsHovered] = useState(false)
  const [breatheOffset, setBreatheOffset] = useState(0)
  const [isMounted, setIsMounted] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  useEffect(() => {
    const handleScroll = () => {
      if (!containerRef.current) return
      const rect = containerRef.current.getBoundingClientRect()
      const viewportHeight = window.innerHeight
      const progress = Math.max(0, Math.min(1, 1 - (rect.top / viewportHeight)))
      setScrollProgress(progress)
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    handleScroll()
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Animate breathe effect only on client after mount
  useEffect(() => {
    if (!isMounted || isHovered) {
      setBreatheOffset(0)
      return
    }
    
    let animationId: number
    const animate = () => {
      setBreatheOffset(Math.sin(Date.now() / 1000) * 2)
      animationId = requestAnimationFrame(animate)
    }
    animationId = requestAnimationFrame(animate)
    
    return () => cancelAnimationFrame(animationId)
  }, [isMounted, isHovered])

  const separationAmount = Math.min(scrollProgress * 100, 60)

  return (
    <div
      ref={containerRef}
      className={`relative w-full max-w-4xl mx-auto h-[400px] md:h-[500px] perspective-[2000px] transition-all duration-700 delay-500 ${
        isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Shadow between layers */}
      <div
        className="absolute inset-x-8 top-1/2 h-32 -translate-y-1/2 transition-all duration-500"
        style={{
          background: `radial-gradient(ellipse at center, oklch(0 0 0 / ${0.1 + separationAmount * 0.003}) 0%, transparent 70%)`,
          filter: `blur(${15 + separationAmount * 0.3}px)`,
          transform: `translateY(${separationAmount * 0.5}px)`,
        }}
      />

      {/* Top Layer - Application Interface */}
      <div
        className={cn(
          'absolute inset-0 transition-transform duration-500',
          'will-change-transform'
        )}
        style={{
          transform: `
            translate3d(${-separationAmount * 0.3}px, ${-separationAmount - breatheOffset}px, ${separationAmount * 2}px)
            rotateX(${10 + scrollProgress * 5}deg)
            rotateY(${-5 - scrollProgress * 3}deg)
          `,
          transformStyle: 'preserve-3d',
          transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        <div className="relative w-full h-full rounded-2xl overflow-hidden border border-border/50 bg-card/80 backdrop-blur-xl shadow-2xl">
          {/* Layer label */}
          <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-secondary/50 border border-border/30">
            <span className="text-xs font-medium text-muted-foreground">Application Layer</span>
          </div>

          {/* Mock App UI */}
          <div className="absolute inset-6 top-14 flex flex-col gap-4">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <div className="text-sm font-medium">Clinical Decision Agent</div>
                  <div className="text-xs text-muted-foreground">Making recommendation...</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                <span className="text-xs text-accent">Active</span>
              </div>
            </div>

            {/* Decision Card */}
            <div className="flex-1 rounded-xl bg-secondary/30 border border-border/30 p-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
                  <svg className="w-4 h-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium mb-2">Treatment Recommendation</div>
                  <div className="h-2 w-3/4 bg-muted-foreground/20 rounded mb-2" />
                  <div className="h-2 w-1/2 bg-muted-foreground/20 rounded" />
                </div>
              </div>
              
              {/* Animated typing indicator */}
              <div className="flex items-center gap-1 mt-4 ml-11">
                <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>

          {/* Glowing edge */}
          <div className="absolute inset-0 rounded-2xl pointer-events-none" style={{
            boxShadow: 'inset 0 0 30px oklch(0.75 0.18 195 / 0.1)',
          }} />
        </div>
      </div>

      {/* Bottom Layer - Velarix Reasoning Engine */}
      <div
        className={cn(
          'absolute inset-0 transition-transform duration-500',
          'will-change-transform'
        )}
        style={{
          transform: `
            translate3d(${separationAmount * 0.2}px, ${separationAmount * 0.5 + breatheOffset}px, ${-separationAmount}px)
            rotateX(${10 + scrollProgress * 5}deg)
            rotateY(${-5 - scrollProgress * 3}deg)
          `,
          transformStyle: 'preserve-3d',
          transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        <div className="relative w-full h-full rounded-2xl overflow-hidden border border-primary/30 bg-gradient-to-br from-secondary/90 to-card/90 backdrop-blur-xl shadow-2xl">
          {/* Layer label */}
          <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-primary/20 border border-primary/30">
            <span className="text-xs font-medium text-primary">Velarix Reasoning Layer</span>
          </div>

          {/* Causal Graph Visualization */}
          <div className="absolute inset-6 top-14">
            <CausalGraphMini />
          </div>

          {/* Glowing edge */}
          <div className="absolute inset-0 rounded-2xl pointer-events-none glow-cyan opacity-30" />
        </div>
      </div>

      {/* Connection lines between layers */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none"
        style={{
          opacity: Math.min(separationAmount / 30, 1),
        }}
      >
        <defs>
          <linearGradient id="connectionGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="oklch(0.75 0.18 195 / 0.5)" />
            <stop offset="100%" stopColor="oklch(0.70 0.20 160 / 0.5)" />
          </linearGradient>
        </defs>
        {[0.3, 0.5, 0.7].map((x, i) => (
          <line
            key={i}
            x1={`${x * 100}%`}
            y1="35%"
            x2={`${x * 100}%`}
            y2="65%"
            stroke="url(#connectionGradient)"
            strokeWidth="1"
            strokeDasharray="4 4"
            className="animate-pulse"
            style={{ animationDelay: `${i * 200}ms` }}
          />
        ))}
      </svg>
    </div>
  )
}

function CausalGraphMini() {
  return (
    <div className="relative w-full h-full">
      {/* Grid background */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(oklch(0.75 0.18 195 / 0.1) 1px, transparent 1px),
            linear-gradient(90deg, oklch(0.75 0.18 195 / 0.1) 1px, transparent 1px)
          `,
          backgroundSize: '20px 20px',
        }}
      />

      {/* Nodes */}
      <GraphNode x={20} y={20} label="Patient Consent" status="valid" pulseDelay={0} />
      <GraphNode x={50} y={15} label="Medical History" status="valid" pulseDelay={200} />
      <GraphNode x={80} y={25} label="Lab Results" status="valid" pulseDelay={400} />
      <GraphNode x={35} y={55} label="Risk Assessment" status="derived" pulseDelay={600} />
      <GraphNode x={65} y={50} label="Drug Interactions" status="derived" pulseDelay={800} />
      <GraphNode x={50} y={85} label="Treatment Plan" status="output" pulseDelay={1000} />

      {/* Edges with flowing particles */}
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        <defs>
          <marker id="arrowhead" markerWidth="6" markerHeight="4" refX="6" refY="2" orient="auto">
            <polygon points="0 0, 6 2, 0 4" fill="oklch(0.75 0.18 195 / 0.6)" />
          </marker>
        </defs>
        <Edge x1={25} y1={25} x2={35} y2={50} />
        <Edge x1={50} y1={20} x2={40} y2={50} />
        <Edge x1={50} y1={20} x2={60} y2={45} />
        <Edge x1={75} y1={30} x2={65} y2={45} />
        <Edge x1={40} y1={60} x2={48} y2={80} />
        <Edge x1={65} y1={55} x2={52} y2={80} />
      </svg>
    </div>
  )
}

function GraphNode({ 
  x, 
  y, 
  label, 
  status, 
  pulseDelay 
}: { 
  x: number
  y: number
  label: string
  status: 'valid' | 'derived' | 'output'
  pulseDelay: number
}) {
  const colors = {
    valid: 'from-accent to-accent/80',
    derived: 'from-primary to-primary/80',
    output: 'from-chart-4 to-chart-4/80',
  }

  const glowColors = {
    valid: 'oklch(0.70 0.20 160 / 0.5)',
    derived: 'oklch(0.75 0.18 195 / 0.5)',
    output: 'oklch(0.70 0.22 320 / 0.5)',
  }

  return (
    <div
      className="absolute flex flex-col items-center gap-1 -translate-x-1/2 -translate-y-1/2"
      style={{ left: `${x}%`, top: `${y}%` }}
    >
      <div
        className={cn(
          'w-3 h-3 md:w-4 md:h-4 rounded-full bg-gradient-to-br animate-pulse',
          colors[status]
        )}
        style={{
          animationDelay: `${pulseDelay}ms`,
          boxShadow: `0 0 10px ${glowColors[status]}, 0 0 20px ${glowColors[status]}`,
        }}
      />
      <span className="text-[8px] md:text-[10px] text-muted-foreground whitespace-nowrap font-medium">
        {label}
      </span>
    </div>
  )
}

function Edge({ x1, y1, x2, y2 }: { x1: number; y1: number; x2: number; y2: number }) {
  return (
    <g>
      <line
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        stroke="oklch(0.75 0.18 195 / 0.3)"
        strokeWidth="0.5"
        markerEnd="url(#arrowhead)"
      />
      {/* Flowing particle */}
      <circle r="0.8" fill="oklch(0.75 0.18 195)">
        <animateMotion
          dur="2s"
          repeatCount="indefinite"
          path={`M${x1},${y1} L${x2},${y2}`}
        />
        <animate
          attributeName="opacity"
          values="0;1;1;0"
          dur="2s"
          repeatCount="indefinite"
        />
      </circle>
    </g>
  )
}
