'use client'

import { useRef, useEffect, useState } from 'react'
import { cn } from '@/lib/utils'

export function UseCasesSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const [isVisible, setIsVisible] = useState(false)
  const [activeStep, setActiveStep] = useState(0)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          // Animate through the cascade
          const interval = setInterval(() => {
            setActiveStep((prev) => {
              if (prev >= 4) {
                clearInterval(interval)
                return prev
              }
              return prev + 1
            })
          }, 1200)
          return () => clearInterval(interval)
        }
      },
      { threshold: 0.3 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="use-cases" className="relative py-32 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div
          className={cn(
            'text-center mb-20 transition-all duration-700',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-destructive/10 border border-destructive/30 mb-6">
            <svg className="w-4 h-4 text-destructive" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
            <span className="text-sm text-destructive font-medium">Healthcare</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
            <span className="text-balance">When consent is revoked, everything collapses.</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Watch how Velarix automatically invalidates a treatment recommendation when a patient revokes their consent.
          </p>
        </div>

        {/* Visual Story */}
        <div
          className={cn(
            'relative max-w-4xl mx-auto transition-all duration-700 delay-200',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          {/* Timeline */}
          <div className="relative">
            {/* Central line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-border/50" />

            {/* Steps */}
            <div className="space-y-8">
              <TimelineStep
                step={1}
                activeStep={activeStep}
                title="Patient grants consent"
                description="Medical records access authorized for AI-assisted diagnosis"
                status="valid"
                icon={
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                }
              />

              <TimelineStep
                step={2}
                activeStep={activeStep}
                title="Agent analyzes history"
                description="Clinical decision agent processes medical records and lab results"
                status="valid"
                icon={
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                }
              />

              <TimelineStep
                step={3}
                activeStep={activeStep}
                title="Treatment recommended"
                description="Agent recommends specific medication based on patient data"
                status="valid"
                icon={
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                }
              />

              <TimelineStep
                step={4}
                activeStep={activeStep}
                title="Patient revokes consent"
                description="Consent belief invalidated - causal cascade initiated"
                status="revoked"
                icon={
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                  </svg>
                }
              />

              <TimelineStep
                step={5}
                activeStep={activeStep}
                title="All dependent decisions collapse"
                description="Treatment recommendation automatically invalidated with full audit trail"
                status="collapsed"
                icon={
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                }
              />
            </div>
          </div>

          {/* Cascade visualization */}
          {activeStep >= 4 && (
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              <div
                className="absolute w-full h-full animate-cascade"
                style={{
                  background: 'radial-gradient(circle at 50% 60%, oklch(0.60 0.22 25 / 0.1) 0%, transparent 50%)',
                  animation: 'cascade 2s ease-out forwards',
                }}
              />
            </div>
          )}
        </div>

        {/* Other industries */}
        <div
          className={cn(
            'grid grid-cols-1 md:grid-cols-3 gap-6 mt-20 transition-all duration-700 delay-500',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          <IndustryCard
            icon={
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
              </svg>
            }
            title="Legal"
            description="Track case precedent dependencies and automatically flag outdated legal reasoning."
          />
          <IndustryCard
            icon={
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            }
            title="Finance"
            description="Maintain full audit trails for algorithmic trading decisions and risk assessments."
          />
          <IndustryCard
            icon={
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            }
            title="Insurance"
            description="Ensure claims processing decisions can be explained and defended to regulators."
          />
        </div>
      </div>
    </section>
  )
}

interface TimelineStepProps {
  step: number
  activeStep: number
  title: string
  description: string
  status: 'valid' | 'revoked' | 'collapsed'
  icon: React.ReactNode
}

function TimelineStep({ step, activeStep, title, description, status, icon }: TimelineStepProps) {
  const isActive = activeStep >= step
  const isCollapsed = status === 'collapsed' && activeStep >= step
  const isRevoked = status === 'revoked' && activeStep >= step

  const statusColors = {
    valid: {
      bg: 'bg-accent/20',
      border: 'border-accent/50',
      text: 'text-accent',
      glow: 'shadow-[0_0_20px_oklch(0.70_0.20_160/0.3)]',
    },
    revoked: {
      bg: 'bg-chart-3/20',
      border: 'border-chart-3/50',
      text: 'text-chart-3',
      glow: 'shadow-[0_0_20px_oklch(0.75_0.18_85/0.3)]',
    },
    collapsed: {
      bg: 'bg-destructive/20',
      border: 'border-destructive/50',
      text: 'text-destructive',
      glow: 'shadow-[0_0_20px_oklch(0.60_0.22_25/0.3)]',
    },
  }

  const colors = statusColors[status]

  return (
    <div
      className={cn(
        'relative flex items-start gap-6 transition-all duration-500',
        isActive ? 'opacity-100' : 'opacity-30'
      )}
    >
      {/* Node */}
      <div
        className={cn(
          'relative z-10 w-16 h-16 rounded-2xl flex items-center justify-center transition-all duration-500 border',
          isActive && colors.bg,
          isActive && colors.border,
          isActive && colors.glow,
          !isActive && 'bg-secondary/50 border-border/50'
        )}
      >
        <span className={cn(isActive ? colors.text : 'text-muted-foreground', 'transition-colors duration-500')}>
          {icon}
        </span>
        
        {/* Ripple effect for collapse */}
        {isCollapsed && (
          <div className="absolute inset-0 rounded-2xl">
            <div className="absolute inset-0 rounded-2xl bg-destructive/20 animate-ping" />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 pt-3">
        <h3
          className={cn(
            'text-lg font-semibold mb-1 transition-colors duration-500',
            isRevoked && 'line-through text-chart-3',
            isCollapsed && 'line-through text-destructive'
          )}
        >
          {title}
        </h3>
        <p
          className={cn(
            'text-muted-foreground transition-colors duration-500',
            (isRevoked || isCollapsed) && 'text-muted-foreground/50'
          )}
        >
          {description}
        </p>
      </div>

      {/* Status badge */}
      {isActive && (
        <div
          className={cn(
            'px-3 py-1 rounded-full text-xs font-medium transition-all duration-500',
            colors.bg,
            colors.text
          )}
        >
          {status === 'valid' && 'Valid'}
          {status === 'revoked' && 'Revoked'}
          {status === 'collapsed' && 'Collapsed'}
        </div>
      )}
    </div>
  )
}

function IndustryCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <div className="group relative rounded-2xl border border-border/50 bg-card/50 backdrop-blur-sm p-6 transition-all duration-300 lift-effect hover:border-primary/30">
      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 text-primary group-hover:scale-110 transition-transform duration-300">
        {icon}
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  )
}
