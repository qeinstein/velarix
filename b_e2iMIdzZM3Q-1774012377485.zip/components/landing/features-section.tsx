'use client'

import { useRef, useState, useEffect } from 'react'
import { cn } from '@/lib/utils'

const features = [
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
    title: 'Causal Invalidation',
    description: 'When a foundational fact changes, every downstream decision that depended on it collapses automatically. No stale reasoning.',
    color: 'primary',
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
      </svg>
    ),
    title: 'Multi-Tenant Isolation',
    description: 'Complete session isolation ensures one tenant\'s reasoning never leaks into another. Enterprise-grade security by default.',
    color: 'accent',
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
    title: 'Schema Enforcement',
    description: 'Define strict schemas for beliefs and decisions. The kernel rejects malformed data before it can corrupt your reasoning chain.',
    color: 'chart-3',
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
    ),
    title: 'SOC2 Audit Exports',
    description: 'Export complete reasoning traces in audit-ready formats. Every decision timestamped, every dependency documented.',
    color: 'chart-4',
  },
]

export function FeaturesSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const [visibleCards, setVisibleCards] = useState<boolean[]>(new Array(features.length).fill(false))

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = parseInt(entry.target.getAttribute('data-index') || '0')
            setVisibleCards((prev) => {
              const newState = [...prev]
              newState[index] = true
              return newState
            })
          }
        })
      },
      { threshold: 0.2, rootMargin: '0px 0px -50px 0px' }
    )

    const cards = sectionRef.current?.querySelectorAll('[data-index]')
    cards?.forEach((card) => observer.observe(card))

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="features" className="relative py-32 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-20">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
            <span className="text-balance">Built for regulated industries</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Every feature designed with compliance, auditability, and enterprise security in mind.
          </p>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((feature, index) => (
            <FeatureCard
              key={feature.title}
              feature={feature}
              index={index}
              isVisible={visibleCards[index]}
            />
          ))}
        </div>
      </div>
    </section>
  )
}

interface FeatureCardProps {
  feature: (typeof features)[0]
  index: number
  isVisible: boolean
}

function FeatureCard({ feature, index, isVisible }: FeatureCardProps) {
  const colorClasses: Record<string, { border: string; bg: string; text: string; glow: string }> = {
    primary: {
      border: 'border-primary/30',
      bg: 'bg-primary/10',
      text: 'text-primary',
      glow: 'group-hover:shadow-[0_0_30px_oklch(0.75_0.18_195/0.2)]',
    },
    accent: {
      border: 'border-accent/30',
      bg: 'bg-accent/10',
      text: 'text-accent',
      glow: 'group-hover:shadow-[0_0_30px_oklch(0.70_0.20_160/0.2)]',
    },
    'chart-3': {
      border: 'border-chart-3/30',
      bg: 'bg-chart-3/10',
      text: 'text-chart-3',
      glow: 'group-hover:shadow-[0_0_30px_oklch(0.75_0.18_85/0.2)]',
    },
    'chart-4': {
      border: 'border-chart-4/30',
      bg: 'bg-chart-4/10',
      text: 'text-chart-4',
      glow: 'group-hover:shadow-[0_0_30px_oklch(0.70_0.22_320/0.2)]',
    },
  }

  const colors = colorClasses[feature.color]

  return (
    <div
      data-index={index}
      className={cn(
        'group relative rounded-2xl border bg-card/50 backdrop-blur-sm p-8 transition-all duration-500 lift-effect',
        colors.border,
        colors.glow,
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      )}
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      {/* Icon */}
      <div
        className={cn(
          'w-12 h-12 rounded-xl flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110',
          colors.bg,
          colors.text
        )}
      >
        {feature.icon}
      </div>

      {/* Content */}
      <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
      <p className="text-muted-foreground leading-relaxed">{feature.description}</p>

      {/* Hover gradient */}
      <div
        className={cn(
          'absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none',
          'bg-gradient-to-br from-transparent via-transparent to-transparent'
        )}
        style={{
          background: `radial-gradient(circle at 80% 80%, oklch(0.75 0.18 195 / 0.05), transparent 50%)`,
        }}
      />
    </div>
  )
}
