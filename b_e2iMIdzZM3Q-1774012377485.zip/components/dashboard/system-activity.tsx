'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'

const generateData = () => {
  const hours = ['00:00', '02:00', '04:00', '06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00', '22:00']
  return hours.map((hour, i) => ({
    time: hour,
    facts: Math.floor(Math.random() * 500 + 200 + i * 30),
    events: Math.floor(Math.random() * 300 + 100 + i * 20),
    cascades: Math.floor(Math.random() * 20 + i * 2),
  }))
}

export function SystemActivity() {
  const [data, setData] = useState<ReturnType<typeof generateData>>([])
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setData(generateData())
      setIsLoaded(true)
    }, 800)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div
      className={cn(
        'rounded-xl border border-border/50 bg-card/50 backdrop-blur-sm overflow-hidden transition-all duration-500',
        isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-chart-3/10 flex items-center justify-center">
            <svg className="w-4 h-4 text-chart-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <div>
            <h3 className="font-semibold">System Activity</h3>
            <p className="text-xs text-muted-foreground">Last 24 hours</p>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-primary" />
            <span className="text-xs text-muted-foreground">Facts</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-accent" />
            <span className="text-xs text-muted-foreground">Events</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-chart-4" />
            <span className="text-xs text-muted-foreground">Cascades</span>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="p-4 h-[300px]">
        {!isLoaded ? (
          <div className="w-full h-full flex items-center justify-center">
            <div className="flex items-center gap-2 text-muted-foreground">
              <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              <span className="text-sm">Loading activity data...</span>
            </div>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorFacts" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.75 0.18 195)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.75 0.18 195)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorEvents" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.70 0.20 160)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.70 0.20 160)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorCascades" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.70 0.22 320)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.70 0.22 320)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="time"
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'oklch(0.60 0.03 240)', fontSize: 11 }}
                dy={10}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'oklch(0.60 0.03 240)', fontSize: 11 }}
                dx={-10}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'oklch(0.12 0.025 240 / 0.95)',
                  border: '1px solid oklch(0.25 0.04 240)',
                  borderRadius: '12px',
                  boxShadow: '0 10px 40px oklch(0 0 0 / 0.3)',
                }}
                labelStyle={{ color: 'oklch(0.95 0.01 240)', fontWeight: 600, marginBottom: 8 }}
                itemStyle={{ color: 'oklch(0.80 0.02 240)', fontSize: 12 }}
              />
              <Area
                type="monotone"
                dataKey="facts"
                stroke="oklch(0.75 0.18 195)"
                strokeWidth={2}
                fill="url(#colorFacts)"
                dot={false}
                activeDot={{ r: 4, fill: 'oklch(0.75 0.18 195)', stroke: 'oklch(0.08 0.02 240)', strokeWidth: 2 }}
              />
              <Area
                type="monotone"
                dataKey="events"
                stroke="oklch(0.70 0.20 160)"
                strokeWidth={2}
                fill="url(#colorEvents)"
                dot={false}
                activeDot={{ r: 4, fill: 'oklch(0.70 0.20 160)', stroke: 'oklch(0.08 0.02 240)', strokeWidth: 2 }}
              />
              <Area
                type="monotone"
                dataKey="cascades"
                stroke="oklch(0.70 0.22 320)"
                strokeWidth={2}
                fill="url(#colorCascades)"
                dot={false}
                activeDot={{ r: 4, fill: 'oklch(0.70 0.22 320)', stroke: 'oklch(0.08 0.02 240)', strokeWidth: 2 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  )
}
