'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import Link from 'next/link'

interface JournalEvent {
  id: string
  type: 'fact_asserted' | 'belief_derived' | 'fact_retracted' | 'cascade_triggered' | 'violation_detected'
  message: string
  sessionId: string
  timestamp: string
}

const mockEvents: JournalEvent[] = [
  { id: '1', type: 'fact_asserted', message: 'Patient consent granted for record access', sessionId: 'sess_8x7k2m', timestamp: '2s ago' },
  { id: '2', type: 'belief_derived', message: 'Treatment eligibility confirmed', sessionId: 'sess_8x7k2m', timestamp: '5s ago' },
  { id: '3', type: 'cascade_triggered', message: 'Consent retraction initiated cascade', sessionId: 'sess_1h3k7p', timestamp: '45s ago' },
  { id: '4', type: 'violation_detected', message: 'Strict schema violation in risk model', sessionId: 'sess_2w8j5r', timestamp: '1m ago' },
  { id: '5', type: 'fact_retracted', message: 'Lab result invalidated', sessionId: 'sess_1h3k7p', timestamp: '1m ago' },
  { id: '6', type: 'belief_derived', message: 'New case precedent established', sessionId: 'sess_9p3n1q', timestamp: '2m ago' },
  { id: '7', type: 'fact_asserted', message: 'Portfolio risk threshold updated', sessionId: 'sess_2w8j5r', timestamp: '3m ago' },
]

const eventTypeConfig = {
  fact_asserted: {
    label: 'Fact',
    color: 'bg-primary/10 text-primary border-primary/30',
    icon: (
      <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
      </svg>
    ),
  },
  belief_derived: {
    label: 'Derived',
    color: 'bg-accent/10 text-accent border-accent/30',
    icon: (
      <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
  },
  fact_retracted: {
    label: 'Retracted',
    color: 'bg-chart-3/10 text-chart-3 border-chart-3/30',
    icon: (
      <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
      </svg>
    ),
  },
  cascade_triggered: {
    label: 'Cascade',
    color: 'bg-chart-4/10 text-chart-4 border-chart-4/30',
    icon: (
      <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
      </svg>
    ),
  },
  violation_detected: {
    label: 'Violation',
    color: 'bg-destructive/10 text-destructive border-destructive/30',
    icon: (
      <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
      </svg>
    ),
  },
}

export function JournalFeed() {
  const [events, setEvents] = useState<JournalEvent[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setEvents(mockEvents)
      setIsLoaded(true)
    }, 600)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="rounded-xl border border-border/50 bg-card/50 backdrop-blur-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <svg className="w-4 h-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
            </svg>
          </div>
          <div>
            <h3 className="font-semibold">Recent Journal</h3>
            <p className="text-xs text-muted-foreground">Real-time event stream</p>
          </div>
        </div>
        <Link
          href="/dashboard/journal"
          className="text-xs text-primary hover:text-primary/80 transition-colors"
        >
          View all
        </Link>
      </div>

      {/* Events list */}
      <div className="divide-y divide-border/30 max-h-[400px] overflow-y-auto">
        {!isLoaded ? (
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="px-5 py-3 flex items-start gap-3">
              <div className="w-16 h-5 bg-muted rounded-full animate-pulse" />
              <div className="flex-1 space-y-2">
                <div className="h-4 w-full bg-muted rounded animate-pulse" />
                <div className="h-3 w-1/3 bg-muted/50 rounded animate-pulse" />
              </div>
            </div>
          ))
        ) : (
          events.map((event, index) => (
            <EventRow key={event.id} event={event} delay={index * 50} />
          ))
        )}
      </div>
    </div>
  )
}

function EventRow({ event, delay }: { event: JournalEvent; delay: number }) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), delay)
    return () => clearTimeout(timer)
  }, [delay])

  const config = eventTypeConfig[event.type]

  return (
    <div
      className={cn(
        'px-5 py-3 flex items-start gap-3 hover:bg-secondary/30 transition-all duration-300',
        isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
      )}
    >
      {/* Type badge */}
      <div className={cn('flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border shrink-0', config.color)}>
        {config.icon}
        {config.label}
      </div>

      {/* Event info */}
      <div className="flex-1 min-w-0">
        <p className="text-sm text-foreground">{event.message}</p>
        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
          <span className="font-mono">{event.sessionId}</span>
          <span>•</span>
          <span>{event.timestamp}</span>
        </div>
      </div>
    </div>
  )
}
