'use client'

import { cn } from '@/lib/utils'

interface FactInspectorProps {
  nodeId: string | null
  onClose: () => void
}

interface Lineage {
  id: string
  timestamp: string
  type: 'created' | 'derived' | 'modified' | 'validated'
  author: string
  message: string
}

const mockLineage: Record<string, Lineage[]> = {
  n1: [
    { id: '1', timestamp: '2024-03-20 14:32:01', type: 'created', author: 'consent-service', message: 'Patient consent form submitted' },
    { id: '2', timestamp: '2024-03-20 14:32:02', type: 'validated', author: 'validation-kernel', message: 'Schema validation passed' },
  ],
  n4: [
    { id: '1', timestamp: '2024-03-20 14:32:05', type: 'derived', author: 'eligibility-agent', message: 'Derived from: Patient Consent, Medical History' },
    { id: '2', timestamp: '2024-03-20 14:32:06', type: 'validated', author: 'rules-engine', message: 'Eligibility criteria met' },
  ],
  n7: [
    { id: '1', timestamp: '2024-03-20 14:32:10', type: 'derived', author: 'treatment-planner', message: 'Generated treatment recommendation' },
    { id: '2', timestamp: '2024-03-20 14:32:11', type: 'validated', author: 'clinical-review', message: 'Meets clinical guidelines' },
    { id: '3', timestamp: '2024-03-20 14:32:12', type: 'modified', author: 'dose-calculator', message: 'Adjusted dosage based on weight' },
  ],
}

const nodeDetails: Record<string, { name: string; type: string; status: string; factCount: number; dependencies: string[] }> = {
  n1: { name: 'Patient Consent', type: 'Fact', status: 'Valid', factCount: 1, dependencies: [] },
  n2: { name: 'Medical History', type: 'Fact', status: 'Valid', factCount: 12, dependencies: [] },
  n3: { name: 'Lab Results', type: 'Fact', status: 'Valid', factCount: 8, dependencies: [] },
  n4: { name: 'Eligibility Check', type: 'Belief', status: 'Valid', factCount: 1, dependencies: ['n1', 'n2'] },
  n5: { name: 'Risk Assessment', type: 'Belief', status: 'Valid', factCount: 3, dependencies: ['n1', 'n3'] },
  n6: { name: 'Drug Interactions', type: 'Belief', status: 'Valid', factCount: 2, dependencies: ['n2', 'n3'] },
  n7: { name: 'Treatment Plan', type: 'Decision', status: 'Valid', factCount: 1, dependencies: ['n4', 'n5'] },
  n8: { name: 'Dosage Calc', type: 'Decision', status: 'Valid', factCount: 1, dependencies: ['n5', 'n6'] },
  n9: { name: 'Final Recommendation', type: 'Decision', status: 'Valid', factCount: 1, dependencies: ['n7', 'n8'] },
}

export function FactInspector({ nodeId, onClose }: FactInspectorProps) {
  if (!nodeId) return null

  const details = nodeDetails[nodeId]
  const lineage = mockLineage[nodeId] || []

  const typeColors = {
    created: 'bg-accent/10 text-accent border-accent/30',
    derived: 'bg-primary/10 text-primary border-primary/30',
    modified: 'bg-chart-3/10 text-chart-3 border-chart-3/30',
    validated: 'bg-chart-4/10 text-chart-4 border-chart-4/30',
  }

  return (
    <div className={cn(
      'w-80 border-l border-border/50 bg-card/50 backdrop-blur-sm flex flex-col',
      'animate-in slide-in-from-right duration-300'
    )}>
      {/* Header */}
      <div className="px-4 py-3 border-b border-border/50 flex items-center justify-between">
        <div>
          <h3 className="font-semibold">{details?.name || 'Unknown Node'}</h3>
          <p className="text-xs text-muted-foreground">Fact Inspector</p>
        </div>
        <button
          onClick={onClose}
          className="w-8 h-8 rounded-lg hover:bg-secondary/50 flex items-center justify-center transition-colors"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {/* Details */}
      <div className="p-4 border-b border-border/50 space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="px-3 py-2 rounded-lg bg-secondary/30">
            <span className="text-xs text-muted-foreground">Type</span>
            <p className="text-sm font-medium">{details?.type}</p>
          </div>
          <div className="px-3 py-2 rounded-lg bg-secondary/30">
            <span className="text-xs text-muted-foreground">Status</span>
            <p className="text-sm font-medium text-accent">{details?.status}</p>
          </div>
          <div className="px-3 py-2 rounded-lg bg-secondary/30">
            <span className="text-xs text-muted-foreground">Facts</span>
            <p className="text-sm font-medium">{details?.factCount}</p>
          </div>
          <div className="px-3 py-2 rounded-lg bg-secondary/30">
            <span className="text-xs text-muted-foreground">Dependencies</span>
            <p className="text-sm font-medium">{details?.dependencies.length || 0}</p>
          </div>
        </div>

        {details?.dependencies.length > 0 && (
          <div className="pt-2">
            <span className="text-xs text-muted-foreground">Depends on:</span>
            <div className="flex flex-wrap gap-1 mt-1">
              {details.dependencies.map(dep => (
                <span key={dep} className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-mono">
                  {nodeDetails[dep]?.name || dep}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Lineage / Blame View */}
      <div className="flex-1 overflow-y-auto">
        <div className="px-4 py-3 border-b border-border/50">
          <h4 className="text-sm font-medium flex items-center gap-2">
            <svg className="w-4 h-4 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Belief Lineage
          </h4>
        </div>

        <div className="p-4 space-y-3">
          {lineage.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">No lineage data available</p>
          ) : (
            lineage.map((entry, index) => (
              <div key={entry.id} className="relative pl-4">
                {/* Timeline connector */}
                {index < lineage.length - 1 && (
                  <div className="absolute left-[5px] top-6 bottom-0 w-0.5 bg-border/50" />
                )}
                
                {/* Timeline dot */}
                <div className="absolute left-0 top-1.5 w-3 h-3 rounded-full bg-secondary border-2 border-primary" />

                <div className="pb-3">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={cn('px-2 py-0.5 rounded-full text-xs font-medium border', typeColors[entry.type])}>
                      {entry.type}
                    </span>
                  </div>
                  <p className="text-sm">{entry.message}</p>
                  <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                    <span className="font-mono">{entry.author}</span>
                    <span>•</span>
                    <span>{entry.timestamp}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="p-4 border-t border-border/50 space-y-2">
        <button className="w-full h-9 rounded-lg bg-secondary/50 hover:bg-secondary/70 text-sm font-medium transition-colors flex items-center justify-center gap-2">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Export Audit Trail
        </button>
        <button className="w-full h-9 rounded-lg border border-destructive/30 text-destructive hover:bg-destructive/10 text-sm font-medium transition-colors flex items-center justify-center gap-2">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
          </svg>
          Retract Fact
        </button>
      </div>
    </div>
  )
}
