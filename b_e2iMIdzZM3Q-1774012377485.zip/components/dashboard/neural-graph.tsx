'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { cn } from '@/lib/utils'

interface Node {
  id: string
  x: number
  y: number
  label: string
  type: 'fact' | 'belief' | 'decision'
  status: 'valid' | 'warning' | 'invalid' | 'cascading'
  connections: string[]
}

interface NeuralGraphProps {
  zoom: number
  onNodeSelect: (id: string | null) => void
  selectedNodeId: string | null
  isPlaying: boolean
}

const initialNodes: Node[] = [
  { id: 'n1', x: 150, y: 100, label: 'Patient Consent', type: 'fact', status: 'valid', connections: ['n4', 'n5'] },
  { id: 'n2', x: 350, y: 80, label: 'Medical History', type: 'fact', status: 'valid', connections: ['n4', 'n6'] },
  { id: 'n3', x: 550, y: 120, label: 'Lab Results', type: 'fact', status: 'valid', connections: ['n5', 'n6'] },
  { id: 'n4', x: 200, y: 250, label: 'Eligibility Check', type: 'belief', status: 'valid', connections: ['n7'] },
  { id: 'n5', x: 400, y: 280, label: 'Risk Assessment', type: 'belief', status: 'valid', connections: ['n7', 'n8'] },
  { id: 'n6', x: 600, y: 240, label: 'Drug Interactions', type: 'belief', status: 'valid', connections: ['n8'] },
  { id: 'n7', x: 300, y: 420, label: 'Treatment Plan', type: 'decision', status: 'valid', connections: ['n9'] },
  { id: 'n8', x: 500, y: 400, label: 'Dosage Calc', type: 'decision', status: 'valid', connections: ['n9'] },
  { id: 'n9', x: 400, y: 550, label: 'Final Recommendation', type: 'decision', status: 'valid', connections: [] },
]

export function NeuralGraph({ zoom, onNodeSelect, selectedNodeId, isPlaying }: NeuralGraphProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [nodes, setNodes] = useState<Node[]>(initialNodes)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const animationRef = useRef<number>()
  const particlesRef = useRef<Array<{ x: number; y: number; progress: number; edge: [string, string] }>>([])
  const cascadeRef = useRef<{ nodeId: string; progress: number } | null>(null)

  const statusColors: Record<string, { fill: string; stroke: string; glow: string }> = {
    valid: { fill: 'oklch(0.70 0.20 160)', stroke: 'oklch(0.75 0.22 160)', glow: 'oklch(0.70 0.20 160 / 0.5)' },
    warning: { fill: 'oklch(0.75 0.18 85)', stroke: 'oklch(0.80 0.20 85)', glow: 'oklch(0.75 0.18 85 / 0.5)' },
    invalid: { fill: 'oklch(0.60 0.22 25)', stroke: 'oklch(0.65 0.24 25)', glow: 'oklch(0.60 0.22 25 / 0.5)' },
    cascading: { fill: 'oklch(0.70 0.22 320)', stroke: 'oklch(0.75 0.24 320)', glow: 'oklch(0.70 0.22 320 / 0.5)' },
  }

  const typeColors: Record<string, string> = {
    fact: 'oklch(0.75 0.18 195)',
    belief: 'oklch(0.70 0.20 160)',
    decision: 'oklch(0.70 0.22 320)',
  }

  // Trigger cascade animation periodically
  useEffect(() => {
    if (!isPlaying) return
    
    const triggerCascade = () => {
      cascadeRef.current = { nodeId: 'n1', progress: 0 }
      // Cascade through nodes
      const cascadeNodes = ['n1', 'n4', 'n5', 'n7', 'n8', 'n9']
      cascadeNodes.forEach((nodeId, index) => {
        setTimeout(() => {
          setNodes(prev => prev.map(n => 
            n.id === nodeId ? { ...n, status: 'cascading' as const } : n
          ))
        }, index * 300)
        setTimeout(() => {
          setNodes(prev => prev.map(n => 
            n.id === nodeId ? { ...n, status: 'valid' as const } : n
          ))
        }, index * 300 + 500)
      })
    }

    const interval = setInterval(triggerCascade, 8000)
    triggerCascade()
    return () => clearInterval(interval)
  }, [isPlaying])

  // Animation loop
  useEffect(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const resizeCanvas = () => {
      canvas.width = container.clientWidth
      canvas.height = container.clientHeight
    }
    resizeCanvas()
    window.addEventListener('resize', resizeCanvas)

    let time = 0
    const animate = () => {
      if (!ctx || !canvas) return
      time += 0.016

      ctx.clearRect(0, 0, canvas.width, canvas.height)
      ctx.save()
      ctx.translate(canvas.width / 2 + pan.x, canvas.height / 2 + pan.y)
      ctx.scale(zoom, zoom)
      ctx.translate(-400, -300)

      // Draw grid
      ctx.strokeStyle = 'oklch(0.20 0.02 240 / 0.3)'
      ctx.lineWidth = 0.5
      for (let x = 0; x < 800; x += 40) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, 600)
        ctx.stroke()
      }
      for (let y = 0; y < 600; y += 40) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(800, y)
        ctx.stroke()
      }

      // Draw edges with particles
      nodes.forEach(node => {
        node.connections.forEach(targetId => {
          const target = nodes.find(n => n.id === targetId)
          if (!target) return

          // Edge line
          const gradient = ctx.createLinearGradient(node.x, node.y, target.x, target.y)
          gradient.addColorStop(0, 'oklch(0.75 0.18 195 / 0.4)')
          gradient.addColorStop(1, 'oklch(0.70 0.20 160 / 0.4)')
          
          ctx.beginPath()
          ctx.moveTo(node.x, node.y)
          ctx.lineTo(target.x, target.y)
          ctx.strokeStyle = gradient
          ctx.lineWidth = 1.5
          ctx.stroke()

          // Animated particles along edges
          if (isPlaying) {
            const particleCount = 3
            for (let i = 0; i < particleCount; i++) {
              const progress = ((time * 0.5 + i / particleCount) % 1)
              const px = node.x + (target.x - node.x) * progress
              const py = node.y + (target.y - node.y) * progress
              
              ctx.beginPath()
              ctx.arc(px, py, 2, 0, Math.PI * 2)
              ctx.fillStyle = `oklch(0.75 0.18 195 / ${0.8 - progress * 0.6})`
              ctx.fill()
            }
          }
        })
      })

      // Draw nodes
      nodes.forEach(node => {
        const colors = statusColors[node.status]
        const isSelected = node.id === selectedNodeId
        const breathe = Math.sin(time * 2) * 2

        // Outer glow
        ctx.beginPath()
        ctx.arc(node.x, node.y, 30 + breathe, 0, Math.PI * 2)
        ctx.fillStyle = colors.glow
        ctx.filter = 'blur(15px)'
        ctx.fill()
        ctx.filter = 'none'

        // Node circle
        ctx.beginPath()
        ctx.arc(node.x, node.y, 20 + (isSelected ? 4 : 0), 0, Math.PI * 2)
        ctx.fillStyle = colors.fill
        ctx.fill()
        ctx.strokeStyle = isSelected ? 'oklch(0.95 0.01 240)' : colors.stroke
        ctx.lineWidth = isSelected ? 3 : 2
        ctx.stroke()

        // Type indicator
        ctx.beginPath()
        ctx.arc(node.x, node.y, 8, 0, Math.PI * 2)
        ctx.fillStyle = typeColors[node.type]
        ctx.fill()

        // Label
        ctx.font = '11px Inter, system-ui, sans-serif'
        ctx.textAlign = 'center'
        ctx.fillStyle = 'oklch(0.95 0.01 240)'
        ctx.fillText(node.label, node.x, node.y + 38)
      })

      ctx.restore()
      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
      window.removeEventListener('resize', resizeCanvas)
    }
  }, [nodes, zoom, pan, selectedNodeId, isPlaying])

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button === 0) {
      setIsDragging(true)
      setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y })
    }
  }, [pan])

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (isDragging) {
      setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y })
    }
  }, [isDragging, dragStart])

  const handleMouseUp = useCallback(() => {
    setIsDragging(false)
  }, [])

  const handleClick = useCallback((e: React.MouseEvent) => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container) return

    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left - canvas.width / 2 - pan.x) / zoom + 400
    const y = (e.clientY - rect.top - canvas.height / 2 - pan.y) / zoom + 300

    // Check if clicked on a node
    const clickedNode = nodes.find(node => {
      const dx = node.x - x
      const dy = node.y - y
      return Math.sqrt(dx * dx + dy * dy) < 25
    })

    onNodeSelect(clickedNode?.id || null)
  }, [nodes, zoom, pan, onNodeSelect])

  return (
    <div 
      ref={containerRef}
      className={cn(
        'absolute inset-0 cursor-grab',
        isDragging && 'cursor-grabbing'
      )}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onClick={handleClick}
    >
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,oklch(0.15_0.03_195/0.2),transparent_70%)]" />
      
      <canvas ref={canvasRef} className="w-full h-full" />

      {/* Legend */}
      <div className="absolute bottom-4 left-4 flex items-center gap-4 px-4 py-2 rounded-lg bg-secondary/50 backdrop-blur-sm border border-border/50">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-primary" />
          <span className="text-xs text-muted-foreground">Fact</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-accent" />
          <span className="text-xs text-muted-foreground">Belief</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-chart-4" />
          <span className="text-xs text-muted-foreground">Decision</span>
        </div>
      </div>
    </div>
  )
}
