'use client'

import { cn } from '@/lib/utils'
import { Slider } from '@/components/ui/slider'

interface GraphControlsProps {
  isPlaying: boolean
  onPlayPause: () => void
  playbackSpeed: number
  onSpeedChange: (speed: number) => void
  currentTime: number
  onTimeChange: (time: number) => void
  totalDuration: number
}

export function GraphControls({
  isPlaying,
  onPlayPause,
  playbackSpeed,
  onSpeedChange,
  currentTime,
  onTimeChange,
  totalDuration,
}: GraphControlsProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  return (
    <div className="px-4 py-3 border-t border-border/50 bg-secondary/30">
      <div className="flex items-center gap-4">
        {/* Playback controls */}
        <div className="flex items-center gap-1">
          {/* Step back */}
          <button
            onClick={() => onTimeChange(Math.max(0, currentTime - 5))}
            className="w-8 h-8 rounded-lg hover:bg-secondary/50 flex items-center justify-center transition-colors"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0019 16V8a1 1 0 00-1.6-.8l-5.333 4zM4.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0011 16V8a1 1 0 00-1.6-.8l-5.334 4z" />
            </svg>
          </button>

          {/* Play/Pause */}
          <button
            onClick={onPlayPause}
            className={cn(
              'w-10 h-10 rounded-full flex items-center justify-center transition-all press-effect',
              isPlaying 
                ? 'bg-primary text-primary-foreground glow-cyan' 
                : 'bg-secondary hover:bg-secondary/70'
            )}
          >
            {isPlaying ? (
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            ) : (
              <svg className="w-5 h-5 ml-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            )}
          </button>

          {/* Step forward */}
          <button
            onClick={() => onTimeChange(Math.min(totalDuration, currentTime + 5))}
            className="w-8 h-8 rounded-lg hover:bg-secondary/50 flex items-center justify-center transition-colors"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.933 12.8a1 1 0 000-1.6L6.6 7.2A1 1 0 005 8v8a1 1 0 001.6.8l5.333-4zM19.933 12.8a1 1 0 000-1.6l-5.333-4A1 1 0 0013 8v8a1 1 0 001.6.8l5.333-4z" />
            </svg>
          </button>
        </div>

        {/* Timeline */}
        <div className="flex-1 flex items-center gap-3">
          <span className="text-xs text-muted-foreground font-mono w-12">
            {formatTime(currentTime)}
          </span>
          <div className="flex-1">
            <Slider
              value={[currentTime]}
              max={totalDuration}
              step={1}
              onValueChange={([value]) => onTimeChange(value)}
              className="cursor-pointer"
            />
          </div>
          <span className="text-xs text-muted-foreground font-mono w-12">
            {formatTime(totalDuration)}
          </span>
        </div>

        {/* Speed control */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Speed:</span>
          <div className="flex items-center gap-1">
            {[0.5, 1, 2].map((speed) => (
              <button
                key={speed}
                onClick={() => onSpeedChange(speed)}
                className={cn(
                  'px-2 py-1 rounded text-xs font-medium transition-colors',
                  playbackSpeed === speed
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-secondary/50 text-muted-foreground'
                )}
              >
                {speed}x
              </button>
            ))}
          </div>
        </div>

        {/* Live indicator */}
        {isPlaying && (
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 border border-accent/30">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-accent" />
            </span>
            <span className="text-xs font-medium text-accent">LIVE</span>
          </div>
        )}
      </div>
    </div>
  )
}
