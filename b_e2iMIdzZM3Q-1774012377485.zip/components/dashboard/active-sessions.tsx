'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import Link from 'next/link'

interface Session {
  id: string
  name: string
  factCount: number
  status: 'healthy' | 'warning' | 'error'
  lastActivity: string
}

const mockSessions: Session[] = [
  { id: 'sess_8x7k2m', name: 'Clinical Agent - Patient #4521', factCount: 127, status: 'healthy', lastActivity: '2s ago' },
  { id: 'sess_9p3n1q', name: 'Legal Review - Case #9812', factCount: 89, status: 'healthy', lastActivity: '5s ago' },
  { id: 'sess_2w8j5r', name: 'Risk Assessment - Portfolio Alpha', factCount: 234, status: 'warning', lastActivity: '12s ago' },
  { id: 'sess_4t6m9v', name: 'Claims Processing - #CLM-2847', factCount: 56, status: 'healthy', lastActivity: '18s ago' },
  { id: 'sess_1h3k7p', name: 'Diagnostic Agent - Lab Results', factCount: 312, status: 'error', lastActivity: '45s ago' },
  { id: 'sess_6n2b8w', name: 'Treatment Planning - Oncology', factCount: 178, status: 'healthy', lastActivity: '1m ago' },
]

export function ActiveSessions() {
  const [sessions, setSessions] = useState<Session[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setSessions(mockSessions)
      setIsLoaded(true)
    }, 500)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="rounded-xl border border-border/50 bg-card/50 backdrop-blur-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center">
            <svg className="w-4 h-4 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
          </div>
          <div>
            <h3 className="font-semibold">Active Sessions</h3>
            <p className="text-xs text-muted-foreground">{sessions.length} sessions running</p>
          </div>
        </div>
        <Link
          href="/dashboard/sessions"
          className="text-xs text-primary hover:text-primary/80 transition-colors"
        >
          View all
        </Link>
      </div>

      {/* Sessions list */}
      <div className="divide-y divide-border/30">
        {!isLoaded ? (
          // Skeleton loader
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="px-5 py-3 flex items-center gap-4">
              <div className="w-2 h-2 rounded-full bg-muted animate-pulse" />
              <div className="flex-1 space-y-2">
                <div className="h-4 w-3/4 bg-muted rounded animate-pulse" />
                <div className="h-3 w-1/2 bg-muted/50 rounded animate-pulse" />
              </div>
            </div>
          ))
        ) : (
          sessions.map((session, index) => (
            <SessionRow key={session.id} session={session} delay={index * 50} />
          ))
        )}
      </div>
    </div>
  )
}

function SessionRow({ session, delay }: { session: Session; delay: number }) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), delay)
    return () => clearTimeout(timer)
  }, [delay])

  const statusColors = {
    healthy: {
      dot: 'bg-accent',
      badge: 'bg-accent/10 text-accent',
      pulse: true,
    },
    warning: {
      dot: 'bg-chart-3',
      badge: 'bg-chart-3/10 text-chart-3',
      pulse: true,
    },
    error: {
      dot: 'bg-destructive',
      badge: 'bg-destructive/10 text-destructive',
      pulse: false,
    },
  }

  const colors = statusColors[session.status]

  return (
    <div
      className={cn(
        'px-5 py-3 flex items-center gap-4 hover:bg-secondary/30 transition-all duration-300 cursor-pointer',
        isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
      )}
    >
      {/* Status indicator */}
      <span className="relative flex h-2.5 w-2.5">
        {colors.pulse && (
          <span className={cn('animate-ping absolute inline-flex h-full w-full rounded-full opacity-75', colors.dot)} />
        )}
        <span className={cn('relative inline-flex rounded-full h-2.5 w-2.5', colors.dot)} />
      </span>

      {/* Session info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium truncate">{session.name}</span>
        </div>
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="font-mono">{session.id}</span>
          <span>•</span>
          <span>{session.factCount} facts</span>
        </div>
      </div>

      {/* Status badge */}
      <div className={cn('px-2 py-0.5 rounded-full text-xs font-medium capitalize', colors.badge)}>
        {session.status}
      </div>

      {/* Last activity */}
      <span className="text-xs text-muted-foreground whitespace-nowrap">
        {session.lastActivity}
      </span>
    </div>
  )
}
