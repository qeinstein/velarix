'use client'

import { useEffect, useState, useRef } from 'react'
import { cn } from '@/lib/utils'

interface MetricData {
  label: string
  value: number
  change: number
  changeType: 'increase' | 'decrease'
  color: 'primary' | 'accent' | 'chart-3' | 'destructive'
  sparkline: number[]
}

const metrics: MetricData[] = [
  {
    label: 'Total Facts',
    value: 124847,
    change: 12.5,
    changeType: 'increase',
    color: 'primary',
    sparkline: [30, 45, 35, 50, 40, 60, 55, 70, 65, 80, 75, 85],
  },
  {
    label: 'Active Sessions',
    value: 1284,
    change: 8.2,
    changeType: 'increase',
    color: 'accent',
    sparkline: [20, 25, 30, 28, 35, 40, 38, 45, 50, 48, 55, 52],
  },
  {
    label: 'Logical Events',
    value: 89432,
    change: 23.1,
    changeType: 'increase',
    color: 'chart-3',
    sparkline: [40, 35, 50, 45, 60, 55, 70, 65, 75, 80, 85, 90],
  },
  {
    label: 'Strict Violations',
    value: 23,
    change: 5.3,
    changeType: 'decrease',
    color: 'destructive',
    sparkline: [50, 45, 40, 38, 35, 30, 28, 25, 22, 20, 18, 15],
  },
]

export function MetricCards() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((metric, index) => (
        <MetricCard key={metric.label} metric={metric} delay={index * 100} />
      ))}
    </div>
  )
}

function MetricCard({ metric, delay }: { metric: MetricData; delay: number }) {
  const [displayValue, setDisplayValue] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const cardRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), delay)
        }
      },
      { threshold: 0.5 }
    )

    if (cardRef.current) {
      observer.observe(cardRef.current)
    }

    return () => observer.disconnect()
  }, [delay])

  useEffect(() => {
    if (!isVisible) return

    const duration = 1500
    const startTime = Date.now()
    const startValue = 0
    const endValue = metric.value

    const animate = () => {
      const elapsed = Date.now() - startTime
      const progress = Math.min(elapsed / duration, 1)
      
      // Ease out cubic
      const easeOut = 1 - Math.pow(1 - progress, 3)
      const currentValue = Math.floor(startValue + (endValue - startValue) * easeOut)
      
      setDisplayValue(currentValue)

      if (progress < 1) {
        requestAnimationFrame(animate)
      }
    }

    requestAnimationFrame(animate)
  }, [isVisible, metric.value])

  const colorClasses = {
    primary: {
      border: 'border-l-primary',
      text: 'text-primary',
      bg: 'bg-primary',
      glow: 'shadow-[0_0_20px_oklch(0.75_0.18_195/0.15)]',
    },
    accent: {
      border: 'border-l-accent',
      text: 'text-accent',
      bg: 'bg-accent',
      glow: 'shadow-[0_0_20px_oklch(0.70_0.20_160/0.15)]',
    },
    'chart-3': {
      border: 'border-l-chart-3',
      text: 'text-chart-3',
      bg: 'bg-chart-3',
      glow: 'shadow-[0_0_20px_oklch(0.75_0.18_85/0.15)]',
    },
    destructive: {
      border: 'border-l-destructive',
      text: 'text-destructive',
      bg: 'bg-destructive',
      glow: 'shadow-[0_0_20px_oklch(0.60_0.22_25/0.15)]',
    },
  }

  const colors = colorClasses[metric.color]

  return (
    <div
      ref={cardRef}
      className={cn(
        'relative rounded-xl border border-border/50 bg-card/50 backdrop-blur-sm p-5 transition-all duration-500 lift-effect border-l-4',
        colors.border,
        colors.glow,
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
      )}
    >
      {/* Label */}
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm text-muted-foreground">{metric.label}</span>
        <div
          className={cn(
            'flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full',
            metric.changeType === 'increase' ? 'bg-accent/10 text-accent' : 'bg-destructive/10 text-destructive'
          )}
        >
          {metric.changeType === 'increase' ? (
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
            </svg>
          ) : (
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          )}
          {metric.change}%
        </div>
      </div>

      {/* Value */}
      <div className="flex items-end justify-between">
        <span className={cn('text-3xl font-bold tracking-tight', colors.text)}>
          {displayValue.toLocaleString()}
        </span>

        {/* Sparkline */}
        <Sparkline data={metric.sparkline} color={colors.bg} isVisible={isVisible} />
      </div>
    </div>
  )
}

function Sparkline({ 
  data, 
  color,
  isVisible 
}: { 
  data: number[]
  color: string
  isVisible: boolean
}) {
  const width = 80
  const height = 32
  const max = Math.max(...data)
  const min = Math.min(...data)
  const range = max - min || 1

  const points = data.map((value, index) => {
    const x = (index / (data.length - 1)) * width
    const y = height - ((value - min) / range) * height
    return `${x},${y}`
  }).join(' ')

  const areaPath = `M0,${height} L${points} L${width},${height} Z`

  return (
    <svg width={width} height={height} className="overflow-visible">
      {/* Area fill */}
      <path
        d={areaPath}
        className={cn(color, 'opacity-20')}
        style={{
          transition: 'all 1s ease-out',
          opacity: isVisible ? 0.2 : 0,
        }}
      />
      {/* Line */}
      <polyline
        points={points}
        fill="none"
        className={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        style={{
          stroke: 'currentColor',
          transition: 'all 1s ease-out',
          strokeDasharray: isVisible ? 'none' : '200',
          strokeDashoffset: isVisible ? 0 : 200,
        }}
      />
      {/* End dot */}
      <circle
        cx={width}
        cy={height - ((data[data.length - 1] - min) / range) * height}
        r="3"
        className={cn(color, 'animate-pulse')}
        style={{
          fill: 'currentColor',
          opacity: isVisible ? 1 : 0,
          transition: 'opacity 1s ease-out 0.5s',
        }}
      />
    </svg>
  )
}
